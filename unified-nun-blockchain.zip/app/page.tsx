"use client"

import { useEffect, useState } from "react"
import { UnifiedNUNCore } from "@/lib/unified-nun-core"
import { Dashboard } from "@/components/dashboard"
import { WalletInterface } from "@/components/wallet-interface"
import { MiningInterface } from "@/components/mining-interface"
import { TransactionInterface } from "@/components/transaction-interface"
import { BlockchainExplorer } from "@/components/blockchain-explorer"
import { WelcomeScreen } from "@/components/welcome-screen"
import { Navigation } from "@/components/navigation"
import { StatusBar } from "@/components/status-bar"

export default function UnifiedNUNApp() {
  const [core, setCore] = useState<UnifiedNUNCore | null>(null)
  const [isInitialized, setIsInitialized] = useState(false)
  const [currentView, setCurrentView] = useState<"dashboard" | "wallet" | "mining" | "transactions" | "explorer">(
    "dashboard",
  )
  const [showWelcome, setShowWelcome] = useState(true)

  useEffect(() => {
    const initializeCore = async () => {
      try {
        const nunCore = new UnifiedNUNCore({
          enableP2P: true,
          enableAutoMining: true,
        })

        await nunCore.initialize()
        setCore(nunCore)
        setIsInitialized(true)

        // Hide welcome screen after initialization
        setTimeout(() => setShowWelcome(false), 2000)
      } catch (error) {
        console.error("Failed to initialize UnifiedNUN:", error)
      }
    }

    initializeCore()

    return () => {
      if (core) {
        core.shutdown()
      }
    }
  }, [])

  if (showWelcome || !isInitialized || !core) {
    return <WelcomeScreen isInitialized={isInitialized} />
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case "dashboard":
        return <Dashboard core={core} />
      case "wallet":
        return <WalletInterface core={core} />
      case "mining":
        return <MiningInterface core={core} />
      case "transactions":
        return <TransactionInterface core={core} />
      case "explorer":
        return <BlockchainExplorer core={core} />
      default:
        return <Dashboard core={core} />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <StatusBar core={core} />
      <div className="flex">
        <Navigation currentView={currentView} onViewChange={setCurrentView} core={core} />
        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto">{renderCurrentView()}</div>
        </main>
      </div>
    </div>
  )
}
