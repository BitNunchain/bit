"use client"

import { Badge } from "@/components/ui/badge"
import { Wifi, Users, Blocks } from "lucide-react"
import type { UnifiedNUNCore } from "@/lib/unified-nun-core"
import { useEffect, useState } from "react"

interface StatusBarProps {
  core: UnifiedNUNCore
}

export function StatusBar({ core }: StatusBarProps) {
  const [stats, setStats] = useState<any>(null)

  useEffect(() => {
    const updateStats = () => {
      const platformStats = core.getPlatformStats()
      setStats(platformStats)
    }

    updateStats()
    const interval = setInterval(updateStats, 5000)

    return () => clearInterval(interval)
  }, [core])

  if (!stats) return null

  return (
    <div className="bg-card border-b border-border px-6 py-2">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="text-xs">
            <Blocks className="w-3 h-3 mr-1" />
            Block {stats.blockchain.blockHeight}
          </Badge>
          <Badge variant="outline" className="text-xs">
            <Users className="w-3 h-3 mr-1" />
            {stats.network.connectedPeers} Peers
          </Badge>
          <Badge variant={stats.network.syncStatus === "synced" ? "default" : "secondary"} className="text-xs">
            <Wifi className="w-3 h-3 mr-1" />
            {stats.network.syncStatus}
          </Badge>
        </div>

        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
          <span>Difficulty: {stats.blockchain.difficulty}</span>
          <span>Mempool: {stats.blockchain.mempoolSize}</span>
          <span>Active Wallet: {stats.wallets.activeWallet}</span>
        </div>
      </div>
    </div>
  )
}
