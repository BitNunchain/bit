"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Pickaxe, TrendingUp, Users, Clock, Zap, Award } from "lucide-react"
import type { UnifiedNUNCore } from "@/lib/unified-nun-core"
import { useEffect, useState } from "react"

interface MiningInterfaceProps {
  core: UnifiedNUNCore
}

export function MiningInterface({ core }: MiningInterfaceProps) {
  const [miningStats, setMiningStats] = useState<any>(null)
  const [miningSessions, setMiningSessions] = useState<any[]>([])
  const [isEligible, setIsEligible] = useState(false)
  const [autoMiningActive, setAutoMiningActive] = useState(true)

  useEffect(() => {
    updateMiningData()
    const interval = setInterval(updateMiningData, 3000)
    return () => clearInterval(interval)
  }, [core])

  const updateMiningData = async () => {
    const { miningEngine } = core.getComponents()

    const stats = miningEngine.getMiningStats()
    setMiningStats(stats)

    const sessions = miningEngine.getMiningSessions()
    setMiningSessions(sessions)

    const eligible = await miningEngine.isCurrentVisitorEligible()
    setIsEligible(eligible)

    const autoActive = miningEngine.isAutoMiningActive()
    setAutoMiningActive(autoActive)
  }

  const handleManualMining = async () => {
    const { miningEngine } = core.getComponents()
    const session = await miningEngine.triggerManualMining()
    if (session) {
      updateMiningData()
    }
  }

  const toggleAutoMining = () => {
    const { miningEngine } = core.getComponents()
    miningEngine.setAutoMining(!autoMiningActive)
    setAutoMiningActive(!autoMiningActive)
  }

  if (!miningStats) {
    return <div>Loading mining interface...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Mining Dashboard</h1>
        <p className="text-muted-foreground">Proof-of-Visit mining statistics and controls</p>
      </div>

      {/* Mining Status */}
      <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Pickaxe className="w-5 h-5 text-primary" />
            <span>Mining Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-2xl font-bold text-primary">{autoMiningActive ? "Active" : "Inactive"}</p>
              <p className="text-sm text-muted-foreground">Auto-mining is {autoMiningActive ? "running" : "stopped"}</p>
            </div>
            <Button onClick={toggleAutoMining} variant={autoMiningActive ? "destructive" : "default"}>
              {autoMiningActive ? "Stop Mining" : "Start Mining"}
            </Button>
          </div>

          {isEligible && (
            <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-accent">You're eligible to mine!</p>
                  <p className="text-sm text-muted-foreground">Click to manually trigger mining for this visit</p>
                </div>
                <Button onClick={handleManualMining} className="bg-accent hover:bg-accent/90">
                  <Zap className="w-4 h-4 mr-2" />
                  Mine Now
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Mining Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Visitors</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{miningStats.totalVisitors}</div>
            <p className="text-xs text-muted-foreground">All-time mining attempts</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unique Visitors</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{miningStats.uniqueVisitors}</div>
            <p className="text-xs text-muted-foreground">Successful mining sessions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Rewards</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{miningStats.totalRewards} NUN</div>
            <p className="text-xs text-muted-foreground">Distributed to miners</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Blocks Today</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{miningStats.blocksMinedToday}</div>
            <p className="text-xs text-muted-foreground">Mined in last 24 hours</p>
          </CardContent>
        </Card>
      </div>

      {/* Mining Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Mining Performance</CardTitle>
          <CardDescription>Current network difficulty and block times</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Mining Difficulty</span>
              <span>{miningStats.currentDifficulty}/10</span>
            </div>
            <Progress value={(miningStats.currentDifficulty / 10) * 100} className="h-2" />
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Average Block Time</p>
              <p className="font-medium">{miningStats.averageBlockTime}s</p>
            </div>
            <div>
              <p className="text-muted-foreground">Target Block Time</p>
              <p className="font-medium">60s</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Mining Sessions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Mining Sessions</CardTitle>
          <CardDescription>Latest Proof-of-Visit mining activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {miningSessions.length > 0 ? (
              miningSessions.slice(0, 10).map((session, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        session.status === "mined"
                          ? "bg-primary"
                          : session.status === "pending"
                            ? "bg-accent animate-pulse"
                            : "bg-destructive"
                      }`}
                    />
                    <div>
                      <p className="text-sm font-medium">{session.reward} NUN Reward</p>
                      <p className="text-xs text-muted-foreground">{new Date(session.timestamp).toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground font-mono">
                        {session.minerAddress.substring(0, 20)}...
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge
                      variant={
                        session.status === "mined"
                          ? "default"
                          : session.status === "pending"
                            ? "secondary"
                            : "destructive"
                      }
                    >
                      {session.status}
                    </Badge>
                    {session.blockHash && (
                      <p className="text-xs text-muted-foreground mt-1 font-mono">
                        Block: {session.blockHash.substring(0, 8)}...
                      </p>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <Pickaxe className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No mining sessions yet</p>
                <p className="text-sm text-muted-foreground">Share your platform to start earning mining rewards!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* How It Works */}
      <Card>
        <CardHeader>
          <CardTitle>How Proof-of-Visit Mining Works</CardTitle>
          <CardDescription>Understanding UnifiedNUN's revolutionary mining mechanism</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-medium">For Visitors</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Visit any UnifiedNUN-powered website</li>
                <li>• Automatic visitor detection and verification</li>
                <li>• Earn 1 NUN for each unique visit (24hr cooldown)</li>
                <li>• No downloads or installations required</li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="font-medium">For Website Owners</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Integrate UnifiedNUN into your website</li>
                <li>• Visitors automatically mine blocks</li>
                <li>• Earn transaction fees from network activity</li>
                <li>• Build a cryptocurrency-earning community</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
