"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Wallet, Plus, Download, Upload, Eye, EyeOff, Copy } from "lucide-react"
import type { UnifiedNUNCore } from "@/lib/unified-nun-core"
import { useEffect, useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface WalletInterfaceProps {
  core: UnifiedNUNCore
}

export function WalletInterface({ core }: WalletInterfaceProps) {
  const [wallets, setWallets] = useState<any[]>([])
  const [activeWallet, setActiveWallet] = useState<any>(null)
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [showImportDialog, setShowImportDialog] = useState(false)
  const [newWalletName, setNewWalletName] = useState("")
  const [newWalletPassword, setNewWalletPassword] = useState("")
  const [importData, setImportData] = useState("")
  const [importPassword, setImportPassword] = useState("")
  const [showPrivateKey, setShowPrivateKey] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    updateWalletData()
  }, [core])

  const updateWalletData = () => {
    const { walletManager } = core.getComponents()
    setWallets(walletManager.getAllWallets())
    setActiveWallet(walletManager.getActiveWalletInfo())
  }

  const handleCreateWallet = async () => {
    if (!newWalletName || !newWalletPassword) {
      toast({
        title: "Error",
        description: "Please provide wallet name and password",
        variant: "destructive",
      })
      return
    }

    try {
      const { walletManager } = core.getComponents()
      await walletManager.createWallet(newWalletName, newWalletPassword, true)
      updateWalletData()
      setShowCreateDialog(false)
      setNewWalletName("")
      setNewWalletPassword("")
      toast({
        title: "Success",
        description: "Wallet created successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create wallet",
        variant: "destructive",
      })
    }
  }

  const handleImportWallet = async () => {
    if (!importData || !importPassword) {
      toast({
        title: "Error",
        description: "Please provide backup data and password",
        variant: "destructive",
      })
      return
    }

    try {
      const { walletManager } = core.getComponents()
      await walletManager.importFromBackup(importData, importPassword)
      updateWalletData()
      setShowImportDialog(false)
      setImportData("")
      setImportPassword("")
      toast({
        title: "Success",
        description: "Wallet imported successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to import wallet",
        variant: "destructive",
      })
    }
  }

  const handleUnlockWallet = async (walletId: string, password: string) => {
    try {
      const { walletManager } = core.getComponents()
      const success = await walletManager.unlockWallet(walletId, password)
      if (success) {
        updateWalletData()
        toast({
          title: "Success",
          description: "Wallet unlocked successfully",
        })
      } else {
        toast({
          title: "Error",
          description: "Invalid password",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to unlock wallet",
        variant: "destructive",
      })
    }
  }

  const handleExportWallet = (walletId: string) => {
    try {
      const { walletManager } = core.getComponents()
      const exportData = walletManager.exportWallet(walletId)
      if (exportData) {
        const blob = new Blob([exportData], { type: "application/json" })
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `wallet-backup-${Date.now()}.json`
        a.click()
        URL.revokeObjectURL(url)
        toast({
          title: "Success",
          description: "Wallet backup downloaded",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export wallet",
        variant: "destructive",
      })
    }
  }

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied",
      description: `${label} copied to clipboard`,
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Wallet Management</h1>
          <p className="text-muted-foreground">Manage your NUN wallets and keys</p>
        </div>
        <div className="flex space-x-2">
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create Wallet
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Wallet</DialogTitle>
                <DialogDescription>Create a new wallet to store your NUN cryptocurrency</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="wallet-name">Wallet Name</Label>
                  <Input
                    id="wallet-name"
                    value={newWalletName}
                    onChange={(e) => setNewWalletName(e.target.value)}
                    placeholder="My NUN Wallet"
                  />
                </div>
                <div>
                  <Label htmlFor="wallet-password">Password</Label>
                  <Input
                    id="wallet-password"
                    type="password"
                    value={newWalletPassword}
                    onChange={(e) => setNewWalletPassword(e.target.value)}
                    placeholder="Secure password"
                  />
                </div>
                <Button onClick={handleCreateWallet} className="w-full">
                  Create Wallet
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="w-4 h-4 mr-2" />
                Import Wallet
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Import Wallet</DialogTitle>
                <DialogDescription>Import a wallet from backup data</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="import-data">Backup Data</Label>
                  <Input
                    id="import-data"
                    value={importData}
                    onChange={(e) => setImportData(e.target.value)}
                    placeholder="Paste wallet backup JSON here"
                  />
                </div>
                <div>
                  <Label htmlFor="import-password">Password</Label>
                  <Input
                    id="import-password"
                    type="password"
                    value={importPassword}
                    onChange={(e) => setImportPassword(e.target.value)}
                    placeholder="Wallet password"
                  />
                </div>
                <Button onClick={handleImportWallet} className="w-full">
                  Import Wallet
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="wallets" className="space-y-4">
        <TabsList>
          <TabsTrigger value="wallets">My Wallets</TabsTrigger>
          <TabsTrigger value="active">Active Wallet</TabsTrigger>
        </TabsList>

        <TabsContent value="wallets" className="space-y-4">
          <div className="grid gap-4">
            {wallets.map((wallet) => (
              <Card key={wallet.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center space-x-2">
                        <Wallet className="w-5 h-5" />
                        <span>{wallet.name}</span>
                        {wallet.isDefault && <Badge variant="default">Default</Badge>}
                      </CardTitle>
                      <CardDescription className="font-mono text-xs">{wallet.address}</CardDescription>
                    </div>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" onClick={() => copyToClipboard(wallet.address, "Address")}>
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleExportWallet(wallet.id)}>
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">
                        Created: {new Date(wallet.createdAt).toLocaleDateString()}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Last used: {new Date(wallet.lastUsed).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      {activeWallet?.id !== wallet.id && (
                        <Button
                          size="sm"
                          onClick={() => {
                            const password = prompt("Enter wallet password:")
                            if (password) handleUnlockWallet(wallet.id, password)
                          }}
                        >
                          Unlock
                        </Button>
                      )}
                      {activeWallet?.id === wallet.id && <Badge variant="default">Active</Badge>}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="active" className="space-y-4">
          {activeWallet ? (
            <Card>
              <CardHeader>
                <CardTitle>Active Wallet Details</CardTitle>
                <CardDescription>Currently unlocked wallet information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Wallet Name</Label>
                  <p className="text-sm font-medium">{activeWallet.name}</p>
                </div>
                <div>
                  <Label>Address</Label>
                  <div className="flex items-center space-x-2">
                    <p className="text-sm font-mono bg-muted p-2 rounded flex-1">{activeWallet.address}</p>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyToClipboard(activeWallet.address, "Address")}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <Label>Public Key</Label>
                  <div className="flex items-center space-x-2">
                    <p className="text-sm font-mono bg-muted p-2 rounded flex-1 truncate">{activeWallet.publicKey}</p>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyToClipboard(activeWallet.publicKey, "Public Key")}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Private Key</Label>
                    <Button size="sm" variant="ghost" onClick={() => setShowPrivateKey(!showPrivateKey)}>
                      {showPrivateKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                  </div>
                  <div className="flex items-center space-x-2">
                    <p className="text-sm font-mono bg-muted p-2 rounded flex-1 truncate">
                      {showPrivateKey ? activeWallet.privateKey : "••••••••••••••••••••••••••••••••"}
                    </p>
                    {showPrivateKey && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(activeWallet.privateKey, "Private Key")}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  <p className="text-xs text-destructive mt-1">⚠️ Never share your private key with anyone</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <Wallet className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No wallet is currently active</p>
                <p className="text-sm text-muted-foreground mb-4">Create or unlock a wallet to get started</p>
                <Button onClick={() => setShowCreateDialog(true)}>Create Your First Wallet</Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
