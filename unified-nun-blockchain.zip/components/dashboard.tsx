"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Coins, TrendingUp, Users, Blocks, Pickaxe, ArrowUpRight, Clock } from "lucide-react"
import type { UnifiedNUNCore } from "@/lib/unified-nun-core"
import { useEffect, useState } from "react"

interface DashboardProps {
  core: UnifiedNUNCore
}

export function Dashboard({ core }: DashboardProps) {
  const [stats, setStats] = useState<any>(null)
  const [balance, setBalance] = useState(0)
  const [recentActivity, setRecentActivity] = useState<any[]>([])

  useEffect(() => {
    const updateData = () => {
      const platformStats = core.getPlatformStats()
      setStats(platformStats)

      const { walletManager, miningEngine } = core.getComponents()
      const activeWallet = walletManager.getActiveWalletInfo()

      if (activeWallet) {
        const walletBalance = core.getComponents().blockchain.getBalance(activeWallet.address)
        setBalance(walletBalance)
      }

      const activity = miningEngine.getRecentMiningActivity(5)
      setRecentActivity(activity)
    }

    updateData()
    const interval = setInterval(updateData, 3000)

    return () => clearInterval(interval)
  }, [core])

  if (!stats) {
    return <div>Loading dashboard...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to your UnifiedNUN blockchain platform</p>
      </div>

      {/* Balance Card */}
      <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Coins className="w-5 h-5 text-primary" />
            <span>Your Balance</span>
          </CardTitle>
          <CardDescription>Current NUN holdings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold text-primary mb-2">{balance.toFixed(3)} NUN</div>
          <p className="text-sm text-muted-foreground">Earned through Proof-of-Visit mining</p>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Blocks</CardTitle>
            <Blocks className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.blockchain.blockHeight + 1}</div>
            <p className="text-xs text-muted-foreground">+{stats.mining.blocksMinedToday} today</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unique Visitors</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.mining.uniqueVisitors}</div>
            <p className="text-xs text-muted-foreground">Total mining participants</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Network Peers</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.network.connectedPeers}</div>
            <p className="text-xs text-muted-foreground">Connected nodes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mining Difficulty</CardTitle>
            <Pickaxe className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.blockchain.difficulty}</div>
            <p className="text-xs text-muted-foreground">Current difficulty level</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="w-5 h-5" />
              <span>Recent Mining Activity</span>
            </CardTitle>
            <CardDescription>Latest Proof-of-Visit mining sessions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentActivity.length > 0 ? (
                recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div
                        className={`w-2 h-2 rounded-full ${
                          activity.status === "mined"
                            ? "bg-primary"
                            : activity.status === "pending"
                              ? "bg-accent animate-pulse"
                              : "bg-destructive"
                        }`}
                      />
                      <div>
                        <p className="text-sm font-medium">{activity.reward} NUN</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(activity.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    <Badge
                      variant={
                        activity.status === "mined"
                          ? "default"
                          : activity.status === "pending"
                            ? "secondary"
                            : "destructive"
                      }
                    >
                      {activity.status}
                    </Badge>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No mining activity yet. Share your site to start earning!
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common tasks and features</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full justify-start bg-transparent" variant="outline">
              <ArrowUpRight className="w-4 h-4 mr-2" />
              Send NUN
            </Button>
            <Button className="w-full justify-start bg-transparent" variant="outline">
              <Pickaxe className="w-4 h-4 mr-2" />
              View Mining Stats
            </Button>
            <Button className="w-full justify-start bg-transparent" variant="outline">
              <Blocks className="w-4 h-4 mr-2" />
              Explore Blockchain
            </Button>
            <Button className="w-full justify-start bg-transparent" variant="outline">
              <Users className="w-4 h-4 mr-2" />
              Share Platform
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Welcome Message for New Users */}
      {balance === 0 && (
        <Card className="border-accent/50 bg-accent/5">
          <CardHeader>
            <CardTitle className="text-accent">Welcome to UnifiedNUN!</CardTitle>
            <CardDescription>You're about to experience the world's first Proof-of-Visit blockchain</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <p>
                🎉 <strong>You've already earned your first NUN</strong> just by visiting!
              </p>
              <p>🔗 Share this platform with others to help them earn NUN too</p>
              <p>⚡ Every unique visitor automatically mines a new block</p>
              <p>🌐 Everything runs in your browser - no downloads needed</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
