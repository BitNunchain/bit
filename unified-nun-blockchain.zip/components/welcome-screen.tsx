import { Card } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

interface WelcomeScreenProps {
  isInitialized: boolean
}

export function WelcomeScreen({ isInitialized }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8 text-center animate-slide-up">
        <div className="mb-6">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl font-bold text-primary-foreground">N</span>
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">UnifiedNUN</h1>
          <p className="text-muted-foreground">Revolutionary Zero-Cost Blockchain Platform</p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-center space-x-2">
            <Loader2 className="w-5 h-5 animate-spin text-primary" />
            <span className="text-sm text-muted-foreground">
              {isInitialized ? "Starting mining engine..." : "Initializing blockchain..."}
            </span>
          </div>

          <div className="text-xs text-muted-foreground space-y-1">
            <p>✓ Proof-of-Visit Mining</p>
            <p>✓ Zero Infrastructure Costs</p>
            <p>✓ Decentralized P2P Network</p>
            <p>✓ Browser-Based Wallet</p>
          </div>
        </div>

        <div className="mt-6 p-4 bg-muted rounded-lg">
          <p className="text-xs text-muted-foreground">
            <strong>Welcome Bonus:</strong> You'll earn 1 NUN just for visiting!
          </p>
        </div>
      </Card>
    </div>
  )
}
