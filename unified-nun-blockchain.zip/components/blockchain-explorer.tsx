"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Blocks, Search, ArrowRight } from "lucide-react"
import type { UnifiedNUNCore } from "@/lib/unified-nun-core"
import { useEffect, useState } from "react"

interface BlockchainExplorerProps {
  core: UnifiedNUNCore
}

export function BlockchainExplorer({ core }: BlockchainExplorerProps) {
  const [blocks, setBlocks] = useState<any[]>([])
  const [selectedBlock, setSelectedBlock] = useState<any>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResult, setSearchResult] = useState<any>(null)

  useEffect(() => {
    updateBlockchainData()
    const interval = setInterval(updateBlockchainData, 5000)
    return () => clearInterval(interval)
  }, [core])

  const updateBlockchainData = () => {
    const { blockchain } = core.getComponents()
    const state = blockchain.getState()
    setBlocks([...state.blocks].reverse()) // Show newest first
  }

  const handleSearch = () => {
    if (!searchQuery) return

    const { blockchain } = core.getComponents()
    const state = blockchain.getState()

    // Search for block by hash or index
    const blockByHash = state.blocks.find((block) => block.hash === searchQuery)
    const blockByIndex = state.blocks.find((block) => block.header.index.toString() === searchQuery)

    // Search for transaction by ID
    let transactionResult = null
    for (const block of state.blocks) {
      const tx = block.transactions.find((tx) => tx.id === searchQuery)
      if (tx) {
        transactionResult = { transaction: tx, block }
        break
      }
    }

    const result = blockByHash || blockByIndex || transactionResult
    setSearchResult(result)
  }

  const formatHash = (hash: string) => {
    return `${hash.substring(0, 8)}...${hash.substring(hash.length - 8)}`
  }

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleString()
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Blockchain Explorer</h1>
        <p className="text-muted-foreground">Explore the UnifiedNUN blockchain</p>
      </div>

      {/* Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Search className="w-5 h-5" />
            <span>Search Blockchain</span>
          </CardTitle>
          <CardDescription>Search by block hash, block number, or transaction ID</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Enter block hash, number, or transaction ID..."
              className="font-mono"
            />
            <Button onClick={handleSearch}>
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </div>

          {searchResult && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              {searchResult.transaction ? (
                <div>
                  <h4 className="font-medium mb-2">Transaction Found</h4>
                  <div className="space-y-1 text-sm">
                    <p>
                      <strong>ID:</strong> <span className="font-mono">{searchResult.transaction.id}</span>
                    </p>
                    <p>
                      <strong>From:</strong> <span className="font-mono">{searchResult.transaction.from}</span>
                    </p>
                    <p>
                      <strong>To:</strong> <span className="font-mono">{searchResult.transaction.to}</span>
                    </p>
                    <p>
                      <strong>Amount:</strong> {searchResult.transaction.amount} NUN
                    </p>
                    <p>
                      <strong>Block:</strong> {searchResult.block.header.index}
                    </p>
                  </div>
                </div>
              ) : (
                <div>
                  <h4 className="font-medium mb-2">Block Found</h4>
                  <div className="space-y-1 text-sm">
                    <p>
                      <strong>Index:</strong> {searchResult.header.index}
                    </p>
                    <p>
                      <strong>Hash:</strong> <span className="font-mono">{formatHash(searchResult.hash)}</span>
                    </p>
                    <p>
                      <strong>Transactions:</strong> {searchResult.transactions.length}
                    </p>
                    <p>
                      <strong>Timestamp:</strong> {formatTimestamp(searchResult.header.timestamp)}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="blocks" className="space-y-4">
        <TabsList>
          <TabsTrigger value="blocks">Recent Blocks</TabsTrigger>
          <TabsTrigger value="details">Block Details</TabsTrigger>
        </TabsList>

        <TabsContent value="blocks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Blocks className="w-5 h-5" />
                <span>Recent Blocks</span>
              </CardTitle>
              <CardDescription>Latest blocks in the UnifiedNUN blockchain</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {blocks.slice(0, 20).map((block, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-muted rounded-lg cursor-pointer hover:bg-muted/80"
                    onClick={() => setSelectedBlock(block)}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold text-primary-foreground">{block.header.index}</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Block #{block.header.index}</p>
                        <p className="text-xs text-muted-foreground">{formatTimestamp(block.header.timestamp)}</p>
                        <p className="text-xs text-muted-foreground font-mono">{formatHash(block.hash)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline">{block.transactions.length} txs</Badge>
                      <p className="text-xs text-muted-foreground mt-1">Difficulty: {block.header.difficulty}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="details" className="space-y-4">
          {selectedBlock ? (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Block #{selectedBlock.header.index} Details</CardTitle>
                  <CardDescription>Complete block information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2">Block Header</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Index:</span>
                          <span>{selectedBlock.header.index}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Timestamp:</span>
                          <span>{formatTimestamp(selectedBlock.header.timestamp)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Difficulty:</span>
                          <span>{selectedBlock.header.difficulty}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Nonce:</span>
                          <span>{selectedBlock.header.nonce}</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Hashes</h4>
                      <div className="space-y-2 text-sm">
                        <div>
                          <span className="text-muted-foreground">Block Hash:</span>
                          <p className="font-mono text-xs break-all">{selectedBlock.hash}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Previous Hash:</span>
                          <p className="font-mono text-xs break-all">{selectedBlock.header.previousHash}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Merkle Root:</span>
                          <p className="font-mono text-xs break-all">{selectedBlock.header.merkleRoot}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <ArrowRight className="w-5 h-5" />
                    <span>Transactions ({selectedBlock.transactions.length})</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {selectedBlock.transactions.map((tx: any, index: number) => (
                      <div key={index} className="p-3 bg-muted rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant={tx.from === "COINBASE" ? "default" : "outline"}>
                            {tx.from === "COINBASE" ? "Mining Reward" : "Transfer"}
                          </Badge>
                          <span className="text-sm font-medium">{tx.amount} NUN</span>
                        </div>
                        <div className="space-y-1 text-xs text-muted-foreground">
                          <p>
                            <strong>ID:</strong> <span className="font-mono">{formatHash(tx.id)}</span>
                          </p>
                          <p>
                            <strong>From:</strong> <span className="font-mono">{tx.from}</span>
                          </p>
                          <p>
                            <strong>To:</strong> <span className="font-mono">{tx.to}</span>
                          </p>
                          {tx.fee > 0 && (
                            <p>
                              <strong>Fee:</strong> {tx.fee} NUN
                            </p>
                          )}
                          <p>
                            <strong>Time:</strong> {formatTimestamp(tx.timestamp)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <Blocks className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Select a block to view details</p>
                <p className="text-sm text-muted-foreground">Click on any block from the Recent Blocks tab</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
