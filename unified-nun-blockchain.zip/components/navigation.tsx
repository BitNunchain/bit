"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { LayoutDashboard, Wallet, Pickaxe, ArrowLeftRight, Blocks } from "lucide-react"
import type { UnifiedNUNCore } from "@/lib/unified-nun-core"

interface NavigationProps {
  currentView: string
  onViewChange: (view: "dashboard" | "wallet" | "mining" | "transactions" | "explorer") => void
  core: UnifiedNUNCore
}

export function Navigation({ currentView, onViewChange, core }: NavigationProps) {
  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "wallet", label: "Wallet", icon: Wallet },
    { id: "mining", label: "Mining", icon: Pickaxe },
    { id: "transactions", label: "Transactions", icon: ArrowLeftRight },
    { id: "explorer", label: "Explorer", icon: Blocks },
  ]

  return (
    <div className="w-64 min-h-screen bg-sidebar border-r border-sidebar-border p-4">
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-2">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <span className="text-sm font-bold text-primary-foreground">N</span>
          </div>
          <div>
            <h2 className="font-bold text-sidebar-foreground">UnifiedNUN</h2>
            <p className="text-xs text-muted-foreground">Blockchain Platform</p>
          </div>
        </div>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = currentView === item.id

          return (
            <Button
              key={item.id}
              variant={isActive ? "default" : "ghost"}
              className={`w-full justify-start ${
                isActive ? "bg-primary text-primary-foreground" : "text-sidebar-foreground hover:bg-sidebar-accent"
              }`}
              onClick={() => onViewChange(item.id as any)}
            >
              <Icon className="w-4 h-4 mr-3" />
              {item.label}
            </Button>
          )
        })}
      </nav>

      <div className="mt-8">
        <Card className="p-4 bg-muted">
          <div className="text-center">
            <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mx-auto mb-2 animate-pulse-green">
              <Pickaxe className="w-6 h-6 text-accent-foreground" />
            </div>
            <p className="text-xs font-medium text-foreground mb-1">Auto-Mining Active</p>
            <p className="text-xs text-muted-foreground">Earning NUN from visitors</p>
          </div>
        </Card>
      </div>
    </div>
  )
}
