"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowUpRight, ArrowDownLeft, Clock, CheckCircle, Send } from "lucide-react"
import type { UnifiedNUNCore } from "@/lib/unified-nun-core"
import { useEffect, useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface TransactionInterfaceProps {
  core: UnifiedNUNCore
}

export function TransactionInterface({ core }: TransactionInterfaceProps) {
  const [balance, setBalance] = useState(0)
  const [recipient, setRecipient] = useState("")
  const [amount, setAmount] = useState("")
  const [fee, setFee] = useState("0.001")
  const [transactions, setTransactions] = useState<any[]>([])
  const [mempool, setMempool] = useState<any[]>([])
  const [activeWallet, setActiveWallet] = useState<any>(null)
  const { toast } = useToast()

  useEffect(() => {
    updateTransactionData()
    const interval = setInterval(updateTransactionData, 5000)
    return () => clearInterval(interval)
  }, [core])

  const updateTransactionData = () => {
    const { walletManager, blockchain } = core.getComponents()
    const wallet = walletManager.getActiveWalletInfo()
    setActiveWallet(wallet)

    if (wallet) {
      const walletBalance = blockchain.getBalance(wallet.address)
      setBalance(walletBalance)

      const history = walletManager.getTransactionHistory(wallet.id)
      setTransactions(history)
    }

    const state = blockchain.getState()
    setMempool(state.mempool)
  }

  const handleSendTransaction = async () => {
    if (!activeWallet) {
      toast({
        title: "Error",
        description: "No active wallet. Please unlock a wallet first.",
        variant: "destructive",
      })
      return
    }

    if (!recipient || !amount) {
      toast({
        title: "Error",
        description: "Please enter recipient address and amount",
        variant: "destructive",
      })
      return
    }

    const amountNum = Number.parseFloat(amount)
    const feeNum = Number.parseFloat(fee)

    if (amountNum <= 0) {
      toast({
        title: "Error",
        description: "Amount must be greater than 0",
        variant: "destructive",
      })
      return
    }

    if (amountNum + feeNum > balance) {
      toast({
        title: "Error",
        description: "Insufficient balance",
        variant: "destructive",
      })
      return
    }

    try {
      const { walletManager, blockchain, storageManager } = core.getComponents()
      const wallet = walletManager.getActiveWallet()

      if (!wallet) {
        toast({
          title: "Error",
          description: "Wallet is locked",
          variant: "destructive",
        })
        return
      }

      const transaction = await wallet.createTransaction(recipient, amountNum, feeNum)

      if (transaction) {
        const added = await blockchain.addTransaction(transaction)

        if (added) {
          await storageManager.broadcastTransaction(transaction)
          walletManager.addTransactionToHistory(activeWallet.id, transaction)

          setRecipient("")
          setAmount("")
          updateTransactionData()

          toast({
            title: "Success",
            description: "Transaction sent successfully",
          })
        } else {
          toast({
            title: "Error",
            description: "Transaction validation failed",
            variant: "destructive",
          })
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send transaction",
        variant: "destructive",
      })
    }
  }

  const formatAddress = (address: string) => {
    return `${address.substring(0, 8)}...${address.substring(address.length - 8)}`
  }

  const getTransactionType = (tx: any, walletAddress: string) => {
    if (tx.from === "COINBASE") return "mining"
    if (tx.from === walletAddress) return "sent"
    if (tx.to === walletAddress) return "received"
    return "unknown"
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Transactions</h1>
        <p className="text-muted-foreground">Send NUN and view transaction history</p>
      </div>

      {/* Balance Card */}
      <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
        <CardHeader>
          <CardTitle>Available Balance</CardTitle>
          <CardDescription>{activeWallet ? `Wallet: ${activeWallet.name}` : "No active wallet"}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-primary">{balance.toFixed(6)} NUN</div>
        </CardContent>
      </Card>

      <Tabs defaultValue="send" className="space-y-4">
        <TabsList>
          <TabsTrigger value="send">Send NUN</TabsTrigger>
          <TabsTrigger value="history">Transaction History</TabsTrigger>
          <TabsTrigger value="mempool">Pending Transactions</TabsTrigger>
        </TabsList>

        <TabsContent value="send" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Send className="w-5 h-5" />
                <span>Send NUN</span>
              </CardTitle>
              <CardDescription>Transfer NUN to another address</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {activeWallet ? (
                <>
                  <div>
                    <Label htmlFor="recipient">Recipient Address</Label>
                    <Input
                      id="recipient"
                      value={recipient}
                      onChange={(e) => setRecipient(e.target.value)}
                      placeholder="NUN1234567890abcdef..."
                      className="font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="amount">Amount (NUN)</Label>
                      <Input
                        id="amount"
                        type="number"
                        step="0.000001"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="0.000000"
                      />
                    </div>
                    <div>
                      <Label htmlFor="fee">Transaction Fee (NUN)</Label>
                      <Input
                        id="fee"
                        type="number"
                        step="0.000001"
                        value={fee}
                        onChange={(e) => setFee(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex justify-between text-sm">
                      <span>Amount:</span>
                      <span>{amount || "0"} NUN</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Fee:</span>
                      <span>{fee} NUN</span>
                    </div>
                    <div className="flex justify-between text-sm font-medium border-t pt-2 mt-2">
                      <span>Total:</span>
                      <span>{(Number.parseFloat(amount || "0") + Number.parseFloat(fee)).toFixed(6)} NUN</span>
                    </div>
                  </div>

                  <Button
                    onClick={handleSendTransaction}
                    className="w-full"
                    disabled={!recipient || !amount || Number.parseFloat(amount || "0") <= 0}
                  >
                    <ArrowUpRight className="w-4 h-4 mr-2" />
                    Send Transaction
                  </Button>
                </>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">
                    No active wallet. Please unlock a wallet to send transactions.
                  </p>
                  <Button variant="outline">Go to Wallet Management</Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>Your recent NUN transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transactions.length > 0 ? (
                  transactions.map((tx, index) => {
                    const type = getTransactionType(tx, activeWallet?.address)
                    return (
                      <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              type === "mining" ? "bg-accent" : type === "sent" ? "bg-destructive" : "bg-primary"
                            }`}
                          >
                            {type === "mining" ? (
                              "⛏️"
                            ) : type === "sent" ? (
                              <ArrowUpRight className="w-4 h-4 text-destructive-foreground" />
                            ) : (
                              <ArrowDownLeft className="w-4 h-4 text-primary-foreground" />
                            )}
                          </div>
                          <div>
                            <p className="text-sm font-medium">
                              {type === "mining" ? "Mining Reward" : type === "sent" ? "Sent" : "Received"}
                            </p>
                            <p className="text-xs text-muted-foreground">{new Date(tx.timestamp).toLocaleString()}</p>
                            <p className="text-xs text-muted-foreground font-mono">
                              {type === "sent"
                                ? `To: ${formatAddress(tx.to)}`
                                : type === "received"
                                  ? `From: ${formatAddress(tx.from)}`
                                  : "Mining Reward"}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`text-sm font-medium ${type === "sent" ? "text-destructive" : "text-primary"}`}>
                            {type === "sent" ? "-" : "+"}
                            {tx.amount.toFixed(6)} NUN
                          </p>
                          {tx.fee > 0 && <p className="text-xs text-muted-foreground">Fee: {tx.fee.toFixed(6)} NUN</p>}
                        </div>
                      </div>
                    )
                  })
                ) : (
                  <div className="text-center py-8">
                    <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No transactions yet</p>
                    <p className="text-sm text-muted-foreground">Your transaction history will appear here</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="mempool" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pending Transactions</CardTitle>
              <CardDescription>Transactions waiting to be mined</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {mempool.length > 0 ? (
                  mempool.map((tx, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
                        <div>
                          <p className="text-sm font-medium">{tx.amount.toFixed(6)} NUN</p>
                          <p className="text-xs text-muted-foreground">{new Date(tx.timestamp).toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground font-mono">
                            {formatAddress(tx.from)} → {formatAddress(tx.to)}
                          </p>
                        </div>
                      </div>
                      <Badge variant="secondary">
                        <Clock className="w-3 h-3 mr-1" />
                        Pending
                      </Badge>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <CheckCircle className="w-12 h-12 text-primary mx-auto mb-4" />
                    <p className="text-muted-foreground">No pending transactions</p>
                    <p className="text-sm text-muted-foreground">All transactions have been processed</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
