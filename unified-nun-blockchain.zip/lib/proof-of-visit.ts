import { CryptoUtils } from "./crypto"

export interface VisitProof {
  domain: string
  timestamp: number
  userAgent: string
  screenResolution: string
  timezone: string
  signature: string
}

export class ProofOfVisit {
  // Generate proof of visit for current session
  static async generateProof(domain: string): Promise<VisitProof> {
    const timestamp = Date.now()
    const userAgent = navigator.userAgent
    const screenResolution = `${screen.width}x${screen.height}`
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone

    // Create unique proof data
    const proofData = `${domain}${timestamp}${userAgent}${screenResolution}${timezone}`
    const signature = await CryptoUtils.hash(proofData)

    return {
      domain,
      timestamp,
      userAgent,
      screenResolution,
      timezone,
      signature,
    }
  }

  // Verify proof of visit
  static async verifyProof(proof: VisitProof): Promise<boolean> {
    try {
      const proofData = `${proof.domain}${proof.timestamp}${proof.userAgent}${proof.screenResolution}${proof.timezone}`
      const expectedSignature = await CryptoUtils.hash(proofData)

      // Check signature
      if (proof.signature !== expectedSignature) return false

      // Check timestamp (must be within last 24 hours)
      const now = Date.now()
      const maxAge = 24 * 60 * 60 * 1000 // 24 hours
      if (now - proof.timestamp > maxAge) return false

      // Basic validation
      if (!proof.domain || !proof.userAgent || !proof.screenResolution || !proof.timezone) {
        return false
      }

      return true
    } catch {
      return false
    }
  }

  // Check if visitor is unique (simplified implementation)
  static async isUniqueVisitor(proof: VisitProof, existingProofs: VisitProof[]): Promise<boolean> {
    const visitorFingerprint = await CryptoUtils.hash(`${proof.userAgent}${proof.screenResolution}${proof.timezone}`)

    // Check if this fingerprint has visited in the last 24 hours
    const now = Date.now()
    const uniqueWindow = 24 * 60 * 60 * 1000 // 24 hours

    for (const existingProof of existingProofs) {
      const existingFingerprint = await CryptoUtils.hash(
        `${existingProof.userAgent}${existingProof.screenResolution}${existingProof.timezone}`,
      )

      if (existingFingerprint === visitorFingerprint && now - existingProof.timestamp < uniqueWindow) {
        return false // Not unique
      }
    }

    return true // Unique visitor
  }

  // Generate mining eligibility proof
  static async generateMiningProof(domain: string, minerAddress: string): Promise<string> {
    const visitProof = await this.generateProof(domain)
    const miningData = `${visitProof.signature}${minerAddress}${Date.now()}`
    return await CryptoUtils.hash(miningData)
  }
}
