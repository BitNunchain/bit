import { CryptoUtils } from "./crypto"

export interface Transaction {
  id: string
  from: string
  to: string
  amount: number
  fee: number
  timestamp: number
  signature: string
  publicKey: string
}

export class TransactionBuilder {
  // Create a new transaction
  static async createTransaction(
    from: string,
    to: string,
    amount: number,
    fee: number,
    privateKey: CryptoKey,
    publicKey: string,
  ): Promise<Transaction> {
    const timestamp = Date.now()
    const transactionData = `${from}${to}${amount}${fee}${timestamp}`
    const signature = await CryptoUtils.sign(transactionData, privateKey)
    const id = await CryptoUtils.hash(transactionData + signature)

    return {
      id,
      from,
      to,
      amount,
      fee,
      timestamp,
      signature,
      publicKey,
    }
  }

  // Verify transaction signature
  static async verifyTransaction(transaction: Transaction): Promise<boolean> {
    try {
      const publicKey = await CryptoUtils.importPublicKey(transaction.publicKey)
      const transactionData = `${transaction.from}${transaction.to}${transaction.amount}${transaction.fee}${transaction.timestamp}`

      // Verify signature
      const isValidSignature = await CryptoUtils.verify(transactionData, transaction.signature, publicKey)

      // Verify address matches public key
      const expectedAddress = await CryptoUtils.generateAddress(transaction.publicKey)
      const isValidAddress = transaction.from === expectedAddress

      // Basic validation
      const isValidAmount = transaction.amount > 0
      const isValidFee = transaction.fee >= 0
      const isValidTimestamp = transaction.timestamp > 0

      return isValidSignature && isValidAddress && isValidAmount && isValidFee && isValidTimestamp
    } catch {
      return false
    }
  }

  // Create coinbase transaction (mining reward)
  static async createCoinbaseTransaction(to: string, amount: number): Promise<Transaction> {
    const timestamp = Date.now()
    const id = await CryptoUtils.hash(`coinbase${to}${amount}${timestamp}`)

    return {
      id,
      from: "COINBASE",
      to,
      amount,
      fee: 0,
      timestamp,
      signature: "",
      publicKey: "",
    }
  }
}
