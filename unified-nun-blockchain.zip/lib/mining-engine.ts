import type { Blockchain } from "./blockchain"
import { ProofOfVisit, type VisitProof } from "./proof-of-visit"
import type { StorageManager } from "./storage-manager"
import type { WalletManager } from "./wallet-manager"

export interface MiningSession {
  id: string
  visitorFingerprint: string
  proof: VisitProof
  minerAddress: string
  blockHash?: string
  reward: number
  timestamp: number
  status: "pending" | "mined" | "failed"
}

export interface MiningStats {
  totalVisitors: number
  uniqueVisitors: number
  totalRewards: number
  blocksMinedToday: number
  currentDifficulty: number
  averageBlockTime: number
}

export class MiningEngine {
  private blockchain: Blockchain
  private storageManager: StorageManager
  private walletManager: WalletManager
  private miningSessions: Map<string, MiningSession> = new Map()
  private visitProofs: VisitProof[] = []
  private isAutoMiningEnabled = true
  private miningInterval: NodeJS.Timeout | null = null
  private readonly MINING_REWARD = 1 // 1 NUN per unique visitor
  private readonly VISIT_COOLDOWN = 24 * 60 * 60 * 1000 // 24 hours
  private readonly storageKey = "unifiednun_mining_sessions"
  private readonly proofsKey = "unifiednun_visit_proofs"

  constructor(blockchain: Blockchain, storageManager: StorageManager, walletManager: WalletManager) {
    this.blockchain = blockchain
    this.storageManager = storageManager
    this.walletManager = walletManager
    this.loadMiningData()
    this.startAutoMining()
  }

  // Start automatic mining for unique visitors
  startAutoMining(): void {
    if (this.miningInterval) return

    this.miningInterval = setInterval(async () => {
      await this.processVisitorMining()
    }, 5000) // Check every 5 seconds

    console.log("[Mining] Auto-mining started")
  }

  // Stop automatic mining
  stopAutoMining(): void {
    if (this.miningInterval) {
      clearInterval(this.miningInterval)
      this.miningInterval = null
    }
    console.log("[Mining] Auto-mining stopped")
  }

  // Process a new visitor for mining
  async processNewVisitor(domain: string = window.location.hostname): Promise<MiningSession | null> {
    try {
      // Generate proof of visit
      const visitProof = await ProofOfVisit.generateProof(domain)

      // Verify the proof is valid
      const isValidProof = await ProofOfVisit.verifyProof(visitProof)
      if (!isValidProof) {
        console.log("[Mining] Invalid visit proof generated")
        return null
      }

      // Check if visitor is unique
      const isUnique = await ProofOfVisit.isUniqueVisitor(visitProof, this.visitProofs)
      if (!isUnique) {
        console.log("[Mining] Visitor is not unique, no mining reward")
        return null
      }

      // Get or create a wallet for mining rewards
      const activeWallet = this.walletManager.getActiveWalletInfo()
      let minerAddress: string

      if (activeWallet) {
        minerAddress = activeWallet.address
      } else {
        // Create a temporary wallet for anonymous visitors
        const tempWallet = await this.walletManager.createWallet(`Visitor-${Date.now()}`, "temp-password", false)
        minerAddress = tempWallet.address
      }

      // Create mining session
      const sessionId = await this.createMiningSession(visitProof, minerAddress)
      const session = this.miningSessions.get(sessionId)

      if (session) {
        // Add proof to our records
        this.visitProofs.push(visitProof)
        this.saveMiningData()

        console.log(`[Mining] New unique visitor detected, mining session created: ${sessionId}`)
        return session
      }

      return null
    } catch (error) {
      console.error("[Mining] Error processing new visitor:", error)
      return null
    }
  }

  // Create a mining session for a unique visitor
  private async createMiningSession(proof: VisitProof, minerAddress: string): Promise<string> {
    const visitorFingerprint = await this.generateVisitorFingerprint(proof)
    const sessionId = await this.generateSessionId(proof, minerAddress)

    const session: MiningSession = {
      id: sessionId,
      visitorFingerprint,
      proof,
      minerAddress,
      reward: this.MINING_REWARD,
      timestamp: Date.now(),
      status: "pending",
    }

    this.miningSessions.set(sessionId, session)
    return sessionId
  }

  // Process visitor mining (called by auto-mining interval)
  private async processVisitorMining(): Promise<void> {
    const pendingSessions = Array.from(this.miningSessions.values()).filter((session) => session.status === "pending")

    for (const session of pendingSessions) {
      try {
        await this.mineBlockForSession(session)
      } catch (error) {
        console.error(`[Mining] Failed to mine block for session ${session.id}:`, error)
        session.status = "failed"
      }
    }

    if (pendingSessions.length > 0) {
      this.saveMiningData()
    }
  }

  // Mine a block for a specific session
  private async mineBlockForSession(session: MiningSession): Promise<void> {
    try {
      // Generate mining proof
      const miningProof = await ProofOfVisit.generateMiningProof(session.proof.domain, session.minerAddress)

      // Mine the block
      const minedBlock = await this.blockchain.mineBlock(session.minerAddress, miningProof)

      if (minedBlock) {
        session.blockHash = minedBlock.hash
        session.status = "mined"

        // Broadcast the new block
        await this.storageManager.broadcastBlock(minedBlock)

        // Add transaction to wallet history if it's a managed wallet
        const walletInfo = this.walletManager.getAllWallets().find((w) => w.address === session.minerAddress)

        if (walletInfo) {
          const rewardTransaction = minedBlock.transactions.find(
            (tx) => tx.to === session.minerAddress && tx.from === "COINBASE",
          )

          if (rewardTransaction) {
            this.walletManager.addTransactionToHistory(walletInfo.id, rewardTransaction)
          }
        }

        console.log(
          `[Mining] Successfully mined block ${minedBlock.header.index} for visitor ${session.visitorFingerprint}`,
        )

        // Emit mining success event
        this.emitMiningEvent("blockMined", {
          session,
          block: minedBlock,
        })
      } else {
        session.status = "failed"
        console.log(`[Mining] Failed to mine block for session ${session.id}`)
      }
    } catch (error) {
      session.status = "failed"
      throw error
    }
  }

  // Manual mining trigger (for testing or manual control)
  async triggerManualMining(domain?: string): Promise<MiningSession | null> {
    const currentDomain = domain || window.location.hostname
    return await this.processNewVisitor(currentDomain)
  }

  // Get mining statistics
  getMiningStats(): MiningStats {
    const now = Date.now()
    const oneDayAgo = now - 24 * 60 * 60 * 1000

    const sessions = Array.from(this.miningSessions.values())
    const todaySessions = sessions.filter((s) => s.timestamp > oneDayAgo)
    const minedSessions = sessions.filter((s) => s.status === "mined")
    const todayMinedSessions = todaySessions.filter((s) => s.status === "mined")

    // Calculate average block time
    const minedBlocks = minedSessions.sort((a, b) => a.timestamp - b.timestamp)
    let averageBlockTime = 0
    if (minedBlocks.length > 1) {
      const totalTime = minedBlocks[minedBlocks.length - 1].timestamp - minedBlocks[0].timestamp
      averageBlockTime = totalTime / (minedBlocks.length - 1)
    }

    return {
      totalVisitors: sessions.length,
      uniqueVisitors: this.visitProofs.length,
      totalRewards: minedSessions.reduce((sum, s) => sum + s.reward, 0),
      blocksMinedToday: todayMinedSessions.length,
      currentDifficulty: this.blockchain.getState().difficulty,
      averageBlockTime: Math.round(averageBlockTime / 1000), // Convert to seconds
    }
  }

  // Get mining sessions
  getMiningSessions(): MiningSession[] {
    return Array.from(this.miningSessions.values()).sort((a, b) => b.timestamp - a.timestamp)
  }

  // Get recent mining activity
  getRecentMiningActivity(limit = 10): MiningSession[] {
    return this.getMiningSessions().slice(0, limit)
  }

  // Check if current visitor is eligible for mining
  async isCurrentVisitorEligible(domain?: string): Promise<boolean> {
    try {
      const currentDomain = domain || window.location.hostname
      const visitProof = await ProofOfVisit.generateProof(currentDomain)
      return await ProofOfVisit.isUniqueVisitor(visitProof, this.visitProofs)
    } catch {
      return false
    }
  }

  // Generate visitor fingerprint
  private async generateVisitorFingerprint(proof: VisitProof): Promise<string> {
    const fingerprintData = `${proof.userAgent}${proof.screenResolution}${proof.timezone}`
    return await import("./crypto").then(({ CryptoUtils }) => CryptoUtils.hash(fingerprintData))
  }

  // Generate session ID
  private async generateSessionId(proof: VisitProof, minerAddress: string): Promise<string> {
    const sessionData = `${proof.signature}${minerAddress}${Date.now()}`
    return await import("./crypto").then(({ CryptoUtils }) => CryptoUtils.hash(sessionData))
  }

  // Save mining data to storage
  private saveMiningData(): void {
    try {
      const sessionsArray = Array.from(this.miningSessions.entries())
      localStorage.setItem(this.storageKey, JSON.stringify(sessionsArray))
      localStorage.setItem(this.proofsKey, JSON.stringify(this.visitProofs))
    } catch (error) {
      console.error("[Mining] Failed to save mining data:", error)
    }
  }

  // Load mining data from storage
  private loadMiningData(): void {
    try {
      // Load mining sessions
      const sessionsStored = localStorage.getItem(this.storageKey)
      if (sessionsStored) {
        const sessionsArray = JSON.parse(sessionsStored)
        this.miningSessions = new Map(sessionsArray)
      }

      // Load visit proofs
      const proofsStored = localStorage.getItem(this.proofsKey)
      if (proofsStored) {
        this.visitProofs = JSON.parse(proofsStored)
      }

      console.log(
        `[Mining] Loaded ${this.miningSessions.size} mining sessions and ${this.visitProofs.length} visit proofs`,
      )
    } catch (error) {
      console.error("[Mining] Failed to load mining data:", error)
    }
  }

  // Event system for mining events
  private eventListeners: Map<string, Function[]> = new Map()

  on(event: string, callback: Function): void {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, [])
    }
    this.eventListeners.get(event)!.push(callback)
  }

  private emitMiningEvent(event: string, data: any): void {
    const listeners = this.eventListeners.get(event)
    if (listeners) {
      listeners.forEach((callback) => {
        try {
          callback(data)
        } catch (error) {
          console.error(`[Mining] Error in event listener for ${event}:`, error)
        }
      })
    }
  }

  // Enable/disable auto mining
  setAutoMining(enabled: boolean): void {
    this.isAutoMiningEnabled = enabled
    if (enabled) {
      this.startAutoMining()
    } else {
      this.stopAutoMining()
    }
  }

  // Get auto mining status
  isAutoMiningActive(): boolean {
    return this.miningInterval !== null
  }

  // Clear all mining data
  clearMiningData(): void {
    this.miningSessions.clear()
    this.visitProofs = []
    localStorage.removeItem(this.storageKey)
    localStorage.removeItem(this.proofsKey)
    console.log("[Mining] All mining data cleared")
  }

  // Cleanup old mining sessions and proofs
  cleanupOldData(): void {
    const now = Date.now()
    const maxAge = 7 * 24 * 60 * 60 * 1000 // 7 days

    // Clean up old sessions
    for (const [sessionId, session] of this.miningSessions.entries()) {
      if (now - session.timestamp > maxAge) {
        this.miningSessions.delete(sessionId)
      }
    }

    // Clean up old proofs
    this.visitProofs = this.visitProofs.filter((proof) => now - proof.timestamp <= maxAge)

    this.saveMiningData()
    console.log("[Mining] Cleaned up old mining data")
  }

  // Shutdown mining engine
  shutdown(): void {
    this.stopAutoMining()
    this.saveMiningData()
    console.log("[Mining] Mining engine shutdown")
  }
}
