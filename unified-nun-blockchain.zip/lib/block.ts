import type { Transaction } from "./transaction"
import { CryptoUtils } from "./crypto"

export interface BlockHeader {
  index: number
  previousHash: string
  merkleRoot: string
  timestamp: number
  nonce: number
  difficulty: number
}

export interface Block {
  header: BlockHeader
  transactions: Transaction[]
  hash: string
}

export class BlockBuilder {
  // Create a new block
  static async createBlock(
    index: number,
    previousHash: string,
    transactions: Transaction[],
    difficulty = 4,
  ): Promise<Block> {
    const timestamp = Date.now()
    const merkleRoot = await this.calculateMerkleRoot(transactions)

    let nonce = 0
    let hash = ""

    // Simple proof of work (for demonstration)
    do {
      const header: BlockHeader = {
        index,
        previousHash,
        merkleRoot,
        timestamp,
        nonce,
        difficulty,
      }

      hash = await this.calculateBlockHash(header, transactions)
      nonce++
    } while (!hash.startsWith("0".repeat(difficulty)))

    const header: BlockHeader = {
      index,
      previousHash,
      merkleRoot,
      timestamp,
      nonce: nonce - 1,
      difficulty,
    }

    return {
      header,
      transactions,
      hash,
    }
  }

  // Calculate block hash
  static async calculateBlockHash(header: BlockHeader, transactions: Transaction[]): Promise<string> {
    const headerString = `${header.index}${header.previousHash}${header.merkleRoot}${header.timestamp}${header.nonce}${header.difficulty}`
    const transactionsString = transactions.map((tx) => tx.id).join("")
    return await CryptoUtils.hash(headerString + transactionsString)
  }

  // Calculate Merkle root of transactions
  static async calculateMerkleRoot(transactions: Transaction[]): Promise<string> {
    if (transactions.length === 0) {
      return await CryptoUtils.hash("")
    }

    if (transactions.length === 1) {
      return await CryptoUtils.hash(transactions[0].id)
    }

    // Simple implementation - hash all transaction IDs together
    const transactionIds = transactions.map((tx) => tx.id).join("")
    return await CryptoUtils.hash(transactionIds)
  }

  // Verify block integrity
  static async verifyBlock(block: Block, previousBlock?: Block): Promise<boolean> {
    try {
      // Verify hash
      const calculatedHash = await this.calculateBlockHash(block.header, block.transactions)
      if (calculatedHash !== block.hash) return false

      // Verify proof of work
      if (!block.hash.startsWith("0".repeat(block.header.difficulty))) return false

      // Verify previous hash (if not genesis block)
      if (previousBlock && block.header.previousHash !== previousBlock.hash) return false

      // Verify merkle root
      const calculatedMerkleRoot = await this.calculateMerkleRoot(block.transactions)
      if (calculatedMerkleRoot !== block.header.merkleRoot) return false

      return true
    } catch {
      return false
    }
  }

  // Create genesis block with pre-mined NUN
  static async createGenesisBlock(founderAddress: string): Promise<Block> {
    const coinbaseTransaction = await import("./transaction").then(
      ({ TransactionBuilder }) => TransactionBuilder.createCoinbaseTransaction(founderAddress, 1000000), // 1M NUN pre-mine
    )

    return await this.createBlock(0, "0", [coinbaseTransaction], 1)
  }
}
