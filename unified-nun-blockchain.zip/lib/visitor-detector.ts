import type { MiningEngine } from "./mining-engine"

export interface VisitorInfo {
  isUnique: boolean
  fingerprint: string
  lastVisit?: number
  visitCount: number
}

export class VisitorDetector {
  private miningEngine: MiningEngine
  private detectionActive = false
  private readonly storageKey = "unifiednun_visitor_info"

  constructor(miningEngine: MiningEngine) {
    this.miningEngine = miningEngine
  }

  // Start visitor detection
  startDetection(): void {
    if (this.detectionActive) return

    this.detectionActive = true

    // Detect visitor immediately
    this.detectCurrentVisitor()

    // Set up page visibility change detection
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) {
        this.detectCurrentVisitor()
      }
    })

    // Set up focus detection
    window.addEventListener("focus", () => {
      this.detectCurrentVisitor()
    })

    console.log("[Visitor] Visitor detection started")
  }

  // Stop visitor detection
  stopDetection(): void {
    this.detectionActive = false
    console.log("[Visitor] Visitor detection stopped")
  }

  // Detect current visitor and trigger mining if eligible
  private async detectCurrentVisitor(): Promise<void> {
    if (!this.detectionActive) return

    try {
      const isEligible = await this.miningEngine.isCurrentVisitorEligible()

      if (isEligible) {
        console.log("[Visitor] Unique visitor detected, triggering mining...")
        const session = await this.miningEngine.processNewVisitor()

        if (session) {
          this.showMiningNotification(session)
        }
      } else {
        console.log("[Visitor] Visitor already seen recently")
      }
    } catch (error) {
      console.error("[Visitor] Error detecting visitor:", error)
    }
  }

  // Show mining notification to user
  private showMiningNotification(session: any): void {
    // Create a simple notification
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification("UnifiedNUN Mining", {
        body: "You earned 1 NUN for visiting! Block mining in progress...",
        icon: "/favicon.ico",
      })
    } else {
      console.log("[Visitor] Mining reward: 1 NUN earned for unique visit")
    }
  }

  // Request notification permission
  async requestNotificationPermission(): Promise<boolean> {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission()
      return permission === "granted"
    }
    return false
  }

  // Get visitor statistics
  getVisitorStats(): {
    detectionActive: boolean
    notificationPermission: string
  } {
    return {
      detectionActive: this.detectionActive,
      notificationPermission: "Notification" in window ? Notification.permission : "not-supported",
    }
  }
}
