import { type Block, BlockBuilder } from "./block"
import { type Transaction, TransactionBuilder } from "./transaction"

export interface ChainState {
  blocks: Block[]
  balances: Map<string, number>
  mempool: Transaction[]
  difficulty: number
}

export class Blockchain {
  private state: ChainState
  private readonly BLOCK_TIME = 60000 // 1 minute target block time
  private readonly DIFFICULTY_ADJUSTMENT_INTERVAL = 10 // Adjust every 10 blocks

  constructor() {
    this.state = {
      blocks: [],
      balances: new Map(),
      mempool: [],
      difficulty: 4,
    }
  }

  // Initialize blockchain with genesis block
  async initialize(founderAddress: string): Promise<void> {
    if (this.state.blocks.length === 0) {
      const genesisBlock = await BlockBuilder.createGenesisBlock(founderAddress)
      this.state.blocks.push(genesisBlock)
      this.updateBalances(genesisBlock)
    }
  }

  // Add transaction to mempool
  async addTransaction(transaction: Transaction): Promise<boolean> {
    // Verify transaction
    const isValid = await TransactionBuilder.verifyTransaction(transaction)
    if (!isValid) return false

    // Check if sender has sufficient balance
    const senderBalance = this.getBalance(transaction.from)
    const totalRequired = transaction.amount + transaction.fee
    if (senderBalance < totalRequired) return false

    // Check for duplicate transaction
    const isDuplicate =
      this.state.mempool.some((tx) => tx.id === transaction.id) ||
      this.state.blocks.some((block) => block.transactions.some((tx) => tx.id === transaction.id))
    if (isDuplicate) return false

    this.state.mempool.push(transaction)
    return true
  }

  // Mine a new block (Proof-of-Visit implementation)
  async mineBlock(minerAddress: string, visitorProof: string): Promise<Block | null> {
    try {
      // Create mining reward transaction
      const miningReward = await TransactionBuilder.createCoinbaseTransaction(minerAddress, 1)

      // Get transactions from mempool (limit to prevent large blocks)
      const transactions = [miningReward, ...this.state.mempool.slice(0, 100)]

      // Create new block
      const previousBlock = this.getLatestBlock()
      const newBlock = await BlockBuilder.createBlock(
        previousBlock.header.index + 1,
        previousBlock.hash,
        transactions,
        this.state.difficulty,
      )

      // Verify block
      const isValid = await BlockBuilder.verifyBlock(newBlock, previousBlock)
      if (!isValid) return null

      // Add block to chain
      this.state.blocks.push(newBlock)

      // Update balances
      this.updateBalances(newBlock)

      // Remove mined transactions from mempool
      this.state.mempool = this.state.mempool.filter(
        (tx) => !newBlock.transactions.some((blockTx) => blockTx.id === tx.id),
      )

      // Adjust difficulty if needed
      this.adjustDifficulty()

      return newBlock
    } catch (error) {
      console.error("Mining failed:", error)
      return null
    }
  }

  // Get balance for an address
  getBalance(address: string): number {
    return this.state.balances.get(address) || 0
  }

  // Get latest block
  getLatestBlock(): Block {
    return this.state.blocks[this.state.blocks.length - 1]
  }

  // Get blockchain state
  getState(): ChainState {
    return { ...this.state }
  }

  // Update balances based on block transactions
  private updateBalances(block: Block): void {
    for (const transaction of block.transactions) {
      if (transaction.from !== "COINBASE") {
        // Deduct from sender
        const senderBalance = this.getBalance(transaction.from)
        this.state.balances.set(transaction.from, senderBalance - transaction.amount - transaction.fee)
      }

      // Add to recipient
      const recipientBalance = this.getBalance(transaction.to)
      this.state.balances.set(transaction.to, recipientBalance + transaction.amount)
    }
  }

  // Adjust mining difficulty
  private adjustDifficulty(): void {
    if (this.state.blocks.length % this.DIFFICULTY_ADJUSTMENT_INTERVAL === 0 && this.state.blocks.length > 1) {
      const latestBlock = this.getLatestBlock()
      const previousAdjustmentBlock = this.state.blocks[this.state.blocks.length - this.DIFFICULTY_ADJUSTMENT_INTERVAL]

      const timeExpected = this.DIFFICULTY_ADJUSTMENT_INTERVAL * this.BLOCK_TIME
      const timeActual = latestBlock.header.timestamp - previousAdjustmentBlock.header.timestamp

      if (timeActual < timeExpected / 2) {
        this.state.difficulty++
      } else if (timeActual > timeExpected * 2) {
        this.state.difficulty = Math.max(1, this.state.difficulty - 1)
      }
    }
  }

  // Validate entire blockchain
  async validateChain(): Promise<boolean> {
    for (let i = 1; i < this.state.blocks.length; i++) {
      const currentBlock = this.state.blocks[i]
      const previousBlock = this.state.blocks[i - 1]

      const isValid = await BlockBuilder.verifyBlock(currentBlock, previousBlock)
      if (!isValid) return false

      // Verify all transactions in block
      for (const transaction of currentBlock.transactions) {
        if (transaction.from !== "COINBASE") {
          const isValidTx = await TransactionBuilder.verifyTransaction(transaction)
          if (!isValidTx) return false
        }
      }
    }

    return true
  }
}
