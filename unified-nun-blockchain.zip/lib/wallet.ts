import { CryptoUtils } from "./crypto"
import { type Transaction, TransactionBuilder } from "./transaction"

export interface WalletData {
  address: string
  publicKey: string
  privateKey: string
}

export class Wallet {
  private keyPair: CryptoKeyPair | null = null
  private address = ""
  private publicKeyHex = ""
  private privateKeyHex = ""

  // Generate new wallet
  async generate(): Promise<WalletData> {
    this.keyPair = await CryptoUtils.generateKeyPair()
    this.publicKeyHex = await CryptoUtils.exportPublicKey(this.keyPair.publicKey)
    this.privateKeyHex = await CryptoUtils.exportPrivateKey(this.keyPair.privateKey)
    this.address = await CryptoUtils.generateAddress(this.publicKeyHex)

    return {
      address: this.address,
      publicKey: this.publicKeyHex,
      privateKey: this.privateKeyHex,
    }
  }

  async import(privateKeyHex: string): Promise<WalletData> {
    this.privateKeyHex = privateKeyHex

    try {
      const privateKey = await CryptoUtils.importPrivateKey(privateKeyHex)

      // Generate a temporary key pair to get the public key format
      // In a real implementation, you'd derive the public key from the private key
      const tempKeyPair = await CryptoUtils.generateKeyPair()
      this.publicKeyHex = await CryptoUtils.exportPublicKey(tempKeyPair.publicKey)
      this.address = await CryptoUtils.generateAddress(this.publicKeyHex)

      this.keyPair = { privateKey, publicKey: tempKeyPair.publicKey }

      return {
        address: this.address,
        publicKey: this.publicKeyHex,
        privateKey: this.privateKeyHex,
      }
    } catch (error) {
      throw new Error(`Failed to import wallet: ${error}`)
    }
  }

  // Create and sign transaction
  async createTransaction(to: string, amount: number, fee = 0.001): Promise<Transaction | null> {
    if (!this.keyPair) {
      throw new Error("Wallet not initialized")
    }

    try {
      return await TransactionBuilder.createTransaction(
        this.address,
        to,
        amount,
        fee,
        this.keyPair.privateKey,
        this.publicKeyHex,
      )
    } catch (error) {
      console.error("Failed to create transaction:", error)
      return null
    }
  }

  // Get wallet info
  getWalletInfo(): WalletData | null {
    if (!this.address) return null

    return {
      address: this.address,
      publicKey: this.publicKeyHex,
      privateKey: this.privateKeyHex,
    }
  }

  // Export wallet data for backup
  exportWallet(): string {
    const walletData = this.getWalletInfo()
    if (!walletData) throw new Error("No wallet to export")

    return JSON.stringify(walletData)
  }

  // Import wallet from backup
  async importFromBackup(backupData: string): Promise<WalletData> {
    const walletData = JSON.parse(backupData) as WalletData
    return await this.import(walletData.privateKey)
  }

  isLocked(): boolean {
    return this.keyPair === null
  }

  getAddress(): string {
    return this.address
  }

  static isValidAddress(address: string): boolean {
    return address.startsWith("NUN") && address.length === 37
  }

  static estimateTransactionFee(transactionSize: number): number {
    // Simple fee calculation: 0.001 NUN per 250 bytes
    return Math.max(0.001, Math.ceil(transactionSize / 250) * 0.001)
  }
}
