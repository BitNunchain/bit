import Gun from "gun"
import "gun/sea"
import "gun/axe"
import type { Block } from "./block"
import type { Transaction } from "./transaction"
import type { Blockchain } from "./blockchain"

export interface PeerInfo {
  id: string
  lastSeen: number
  blockHeight: number
}

export interface NetworkMessage {
  type: "block" | "transaction" | "peer_info" | "chain_request" | "chain_response"
  data: any
  timestamp: number
  from: string
}

export class P2PNetwork {
  private gun: any
  private blockchain: Blockchain
  private nodeId: string
  private peers: Map<string, PeerInfo> = new Map()
  private messageHandlers: Map<string, Function[]> = new Map()
  private syncInProgress = false

  constructor(blockchain: Blockchain, relayPeers: string[] = []) {
    // Initialize Gun with relay peers for better connectivity
    this.gun = Gun({
      peers:
        relayPeers.length > 0
          ? relayPeers
          : ["https://gun-manhattan.herokuapp.com/gun", "https://gun-us.herokuapp.com/gun"],
      localStorage: false, // Use memory only for privacy
      radisk: false,
    })

    this.blockchain = blockchain
    this.nodeId = this.generateNodeId()
    this.setupMessageHandlers()
    this.startPeerDiscovery()
  }

  // Generate unique node ID
  private generateNodeId(): string {
    return "nun_" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
  }

  // Setup message handlers for different message types
  private setupMessageHandlers(): void {
    // Listen for new blocks
    this.gun.get("unifiednun_blocks").on((data: any, key: string) => {
      if (data && key !== "_") {
        this.handleIncomingBlock(data)
      }
    })

    // Listen for new transactions
    this.gun.get("unifiednun_mempool").on((data: any, key: string) => {
      if (data && key !== "_") {
        this.handleIncomingTransaction(data)
      }
    })

    // Listen for peer announcements
    this.gun.get("unifiednun_peers").on((data: any, key: string) => {
      if (data && key !== "_" && key !== this.nodeId) {
        this.handlePeerAnnouncement(data)
      }
    })

    // Listen for chain sync requests
    this.gun.get("unifiednun_sync").on((data: any, key: string) => {
      if (data && key !== "_") {
        this.handleSyncRequest(data)
      }
    })
  }

  // Start peer discovery and announcement
  private startPeerDiscovery(): void {
    // Announce this peer
    this.announcePeer()

    // Periodically announce presence and sync
    setInterval(() => {
      this.announcePeer()
      this.requestChainSync()
    }, 30000) // Every 30 seconds

    // Clean up old peers
    setInterval(() => {
      this.cleanupOldPeers()
    }, 60000) // Every minute
  }

  // Announce this peer to the network
  private announcePeer(): void {
    const peerInfo: PeerInfo = {
      id: this.nodeId,
      lastSeen: Date.now(),
      blockHeight: this.blockchain.getLatestBlock().header.index,
    }

    this.gun.get("unifiednun_peers").get(this.nodeId).put(peerInfo)
  }

  // Handle incoming peer announcements
  private handlePeerAnnouncement(peerData: any): void {
    if (peerData.id && peerData.id !== this.nodeId) {
      this.peers.set(peerData.id, {
        id: peerData.id,
        lastSeen: peerData.lastSeen || Date.now(),
        blockHeight: peerData.blockHeight || 0,
      })
    }
  }

  // Broadcast a new block to the network
  async broadcastBlock(block: Block): Promise<void> {
    const message: NetworkMessage = {
      type: "block",
      data: block,
      timestamp: Date.now(),
      from: this.nodeId,
    }

    // Store block in Gun
    this.gun.get("unifiednun_blocks").get(block.hash).put(message)
  }

  // Handle incoming blocks
  private async handleIncomingBlock(message: NetworkMessage): Promise<void> {
    if (message.from === this.nodeId) return // Ignore own messages

    try {
      const block: Block = message.data
      const latestBlock = this.blockchain.getLatestBlock()

      // Check if this is the next block in sequence
      if (block.header.index === latestBlock.header.index + 1 && block.header.previousHash === latestBlock.hash) {
        // Validate and add block
        const isValid = await import("./block").then(({ BlockBuilder }) => BlockBuilder.verifyBlock(block, latestBlock))

        if (isValid) {
          // Add block to local blockchain
          this.blockchain.getState().blocks.push(block)
          this.updateBalancesFromBlock(block)

          console.log(`[P2P] Added block ${block.header.index} from peer ${message.from}`)
          this.emit("blockAdded", block)
        }
      } else if (block.header.index > latestBlock.header.index + 1) {
        // We're behind, request chain sync
        this.requestChainSync()
      }
    } catch (error) {
      console.error("[P2P] Error handling incoming block:", error)
    }
  }

  // Broadcast a transaction to the network
  async broadcastTransaction(transaction: Transaction): Promise<void> {
    const message: NetworkMessage = {
      type: "transaction",
      data: transaction,
      timestamp: Date.now(),
      from: this.nodeId,
    }

    // Store transaction in Gun mempool
    this.gun.get("unifiednun_mempool").get(transaction.id).put(message)
  }

  // Handle incoming transactions
  private async handleIncomingTransaction(message: NetworkMessage): Promise<void> {
    if (message.from === this.nodeId) return // Ignore own messages

    try {
      const transaction: Transaction = message.data

      // Add to local mempool if valid
      const added = await this.blockchain.addTransaction(transaction)
      if (added) {
        console.log(`[P2P] Added transaction ${transaction.id} from peer ${message.from}`)
        this.emit("transactionAdded", transaction)
      }
    } catch (error) {
      console.error("[P2P] Error handling incoming transaction:", error)
    }
  }

  // Request chain synchronization
  private requestChainSync(): void {
    if (this.syncInProgress) return

    const latestBlock = this.blockchain.getLatestBlock()
    const syncRequest = {
      type: "chain_request",
      data: {
        fromIndex: latestBlock.header.index,
        requesterId: this.nodeId,
      },
      timestamp: Date.now(),
      from: this.nodeId,
    }

    this.gun.get("unifiednun_sync").get(`sync_${Date.now()}`).put(syncRequest)
  }

  // Handle chain sync requests
  private handleSyncRequest(message: NetworkMessage): void {
    if (message.from === this.nodeId) return

    if (message.type === "chain_request") {
      const { fromIndex, requesterId } = message.data
      const blocks = this.blockchain.getState().blocks

      // Send blocks after the requested index
      const blocksToSend = blocks.slice(fromIndex + 1)

      if (blocksToSend.length > 0) {
        const syncResponse = {
          type: "chain_response",
          data: {
            blocks: blocksToSend,
            toRequesterId: requesterId,
          },
          timestamp: Date.now(),
          from: this.nodeId,
        }

        this.gun.get("unifiednun_sync").get(`response_${Date.now()}`).put(syncResponse)
      }
    } else if (message.type === "chain_response" && message.data.toRequesterId === this.nodeId) {
      this.handleChainSyncResponse(message.data.blocks)
    }
  }

  // Handle chain sync response
  private async handleChainSyncResponse(blocks: Block[]): Promise<void> {
    this.syncInProgress = true

    try {
      for (const block of blocks) {
        const latestBlock = this.blockchain.getLatestBlock()

        // Verify block sequence
        if (block.header.index === latestBlock.header.index + 1 && block.header.previousHash === latestBlock.hash) {
          const isValid = await import("./block").then(({ BlockBuilder }) =>
            BlockBuilder.verifyBlock(block, latestBlock),
          )

          if (isValid) {
            this.blockchain.getState().blocks.push(block)
            this.updateBalancesFromBlock(block)
            console.log(`[P2P] Synced block ${block.header.index}`)
          } else {
            console.error(`[P2P] Invalid block during sync: ${block.header.index}`)
            break
          }
        }
      }
    } catch (error) {
      console.error("[P2P] Error during chain sync:", error)
    } finally {
      this.syncInProgress = false
    }
  }

  // Update balances from a new block
  private updateBalancesFromBlock(block: Block): void {
    const balances = this.blockchain.getState().balances

    for (const transaction of block.transactions) {
      if (transaction.from !== "COINBASE") {
        // Deduct from sender
        const senderBalance = balances.get(transaction.from) || 0
        balances.set(transaction.from, senderBalance - transaction.amount - transaction.fee)
      }

      // Add to recipient
      const recipientBalance = balances.get(transaction.to) || 0
      balances.set(transaction.to, recipientBalance + transaction.amount)
    }
  }

  // Clean up old peers
  private cleanupOldPeers(): void {
    const now = Date.now()
    const timeout = 5 * 60 * 1000 // 5 minutes

    for (const [peerId, peerInfo] of this.peers.entries()) {
      if (now - peerInfo.lastSeen > timeout) {
        this.peers.delete(peerId)
      }
    }
  }

  // Get connected peers
  getPeers(): PeerInfo[] {
    return Array.from(this.peers.values())
  }

  // Get network statistics
  getNetworkStats(): {
    connectedPeers: number
    blockHeight: number
    syncStatus: string
  } {
    return {
      connectedPeers: this.peers.size,
      blockHeight: this.blockchain.getLatestBlock().header.index,
      syncStatus: this.syncInProgress ? "syncing" : "synced",
    }
  }

  // Event emitter functionality
  private eventListeners: Map<string, Function[]> = new Map()

  on(event: string, callback: Function): void {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, [])
    }
    this.eventListeners.get(event)!.push(callback)
  }

  private emit(event: string, data: any): void {
    const listeners = this.eventListeners.get(event)
    if (listeners) {
      listeners.forEach((callback) => callback(data))
    }
  }

  // Disconnect from network
  disconnect(): void {
    // Remove peer announcement
    this.gun.get("unifiednun_peers").get(this.nodeId).put(null)
  }
}
