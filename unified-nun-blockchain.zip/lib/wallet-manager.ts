import { CryptoUtils } from "./crypto"
import type { Transaction } from "./transaction"
import { Wallet } from "./wallet"

export interface WalletInfo {
  id: string
  name: string
  address: string
  publicKey: string
  createdAt: number
  lastUsed: number
  isDefault: boolean
}

export interface SecureWalletData {
  id: string
  name: string
  encryptedPrivateKey: string
  publicKey: string
  address: string
  createdAt: number
  lastUsed: number
  isDefault: boolean
}

export interface AddressBookEntry {
  id: string
  name: string
  address: string
  notes?: string
  createdAt: number
}

export interface TransactionHistory {
  walletId: string
  transactions: Transaction[]
  lastUpdated: number
}

export class WalletManager {
  private wallets: Map<string, SecureWalletData> = new Map()
  private activeWallet: Wallet | null = null
  private activeWalletId: string | null = null
  private addressBook: Map<string, AddressBookEntry> = new Map()
  private transactionHistory: Map<string, Transaction[]> = new Map()
  private readonly storageKey = "unifiednun_wallets"
  private readonly addressBookKey = "unifiednun_addressbook"
  private readonly historyKey = "unifiednun_history"

  constructor() {
    this.loadFromStorage()
  }

  // Create a new wallet
  async createWallet(name: string, password: string, setAsDefault = false): Promise<WalletInfo> {
    const wallet = new Wallet()
    const walletData = await wallet.generate()

    const walletId = await CryptoUtils.hash(`${walletData.address}${Date.now()}`)
    const encryptedPrivateKey = await this.encryptPrivateKey(walletData.privateKey, password)

    const secureWalletData: SecureWalletData = {
      id: walletId,
      name,
      encryptedPrivateKey,
      publicKey: walletData.publicKey,
      address: walletData.address,
      createdAt: Date.now(),
      lastUsed: Date.now(),
      isDefault: setAsDefault || this.wallets.size === 0,
    }

    // If this is set as default, unset other defaults
    if (secureWalletData.isDefault) {
      this.wallets.forEach((w) => (w.isDefault = false))
    }

    this.wallets.set(walletId, secureWalletData)
    this.transactionHistory.set(walletId, [])
    this.saveToStorage()

    return {
      id: walletId,
      name,
      address: walletData.address,
      publicKey: walletData.publicKey,
      createdAt: secureWalletData.createdAt,
      lastUsed: secureWalletData.lastUsed,
      isDefault: secureWalletData.isDefault,
    }
  }

  // Import wallet from private key
  async importWallet(name: string, privateKey: string, password: string, setAsDefault = false): Promise<WalletInfo> {
    const wallet = new Wallet()
    const walletData = await wallet.import(privateKey)

    const walletId = await CryptoUtils.hash(`${walletData.address}${Date.now()}`)
    const encryptedPrivateKey = await this.encryptPrivateKey(walletData.privateKey, password)

    const secureWalletData: SecureWalletData = {
      id: walletId,
      name,
      encryptedPrivateKey,
      publicKey: walletData.publicKey,
      address: walletData.address,
      createdAt: Date.now(),
      lastUsed: Date.now(),
      isDefault: setAsDefault || this.wallets.size === 0,
    }

    // If this is set as default, unset other defaults
    if (secureWalletData.isDefault) {
      this.wallets.forEach((w) => (w.isDefault = false))
    }

    this.wallets.set(walletId, secureWalletData)
    this.transactionHistory.set(walletId, [])
    this.saveToStorage()

    return {
      id: walletId,
      name,
      address: walletData.address,
      publicKey: walletData.publicKey,
      createdAt: secureWalletData.createdAt,
      lastUsed: secureWalletData.lastUsed,
      isDefault: secureWalletData.isDefault,
    }
  }

  // Unlock and activate a wallet
  async unlockWallet(walletId: string, password: string): Promise<boolean> {
    const secureWallet = this.wallets.get(walletId)
    if (!secureWallet) return false

    try {
      const privateKey = await this.decryptPrivateKey(secureWallet.encryptedPrivateKey, password)

      const wallet = new Wallet()
      await wallet.import(privateKey)

      this.activeWallet = wallet
      this.activeWalletId = walletId

      // Update last used timestamp
      secureWallet.lastUsed = Date.now()
      this.saveToStorage()

      return true
    } catch {
      return false
    }
  }

  // Lock the active wallet
  lockWallet(): void {
    this.activeWallet = null
    this.activeWalletId = null
  }

  // Get active wallet
  getActiveWallet(): Wallet | null {
    return this.activeWallet
  }

  // Get active wallet info
  getActiveWalletInfo(): WalletInfo | null {
    if (!this.activeWalletId) return null

    const secureWallet = this.wallets.get(this.activeWalletId)
    if (!secureWallet) return null

    return {
      id: secureWallet.id,
      name: secureWallet.name,
      address: secureWallet.address,
      publicKey: secureWallet.publicKey,
      createdAt: secureWallet.createdAt,
      lastUsed: secureWallet.lastUsed,
      isDefault: secureWallet.isDefault,
    }
  }

  // Get all wallet info (without private keys)
  getAllWallets(): WalletInfo[] {
    return Array.from(this.wallets.values()).map((wallet) => ({
      id: wallet.id,
      name: wallet.name,
      address: wallet.address,
      publicKey: wallet.publicKey,
      createdAt: wallet.createdAt,
      lastUsed: wallet.lastUsed,
      isDefault: wallet.isDefault,
    }))
  }

  // Set default wallet
  setDefaultWallet(walletId: string): boolean {
    const wallet = this.wallets.get(walletId)
    if (!wallet) return false

    // Unset all defaults
    this.wallets.forEach((w) => (w.isDefault = false))

    // Set new default
    wallet.isDefault = true
    this.saveToStorage()

    return true
  }

  // Delete wallet
  deleteWallet(walletId: string): boolean {
    const wallet = this.wallets.get(walletId)
    if (!wallet) return false

    // Don't delete if it's the active wallet
    if (this.activeWalletId === walletId) {
      this.lockWallet()
    }

    this.wallets.delete(walletId)
    this.transactionHistory.delete(walletId)

    // If this was the default wallet, set another as default
    if (wallet.isDefault && this.wallets.size > 0) {
      const firstWallet = Array.from(this.wallets.values())[0]
      firstWallet.isDefault = true
    }

    this.saveToStorage()
    return true
  }

  // Rename wallet
  renameWallet(walletId: string, newName: string): boolean {
    const wallet = this.wallets.get(walletId)
    if (!wallet) return false

    wallet.name = newName
    this.saveToStorage()
    return true
  }

  // Add address to address book
  addToAddressBook(name: string, address: string, notes?: string): string {
    const entryId = Date.now().toString()
    const entry: AddressBookEntry = {
      id: entryId,
      name,
      address,
      notes,
      createdAt: Date.now(),
    }

    this.addressBook.set(entryId, entry)
    this.saveAddressBook()
    return entryId
  }

  // Get address book entries
  getAddressBook(): AddressBookEntry[] {
    return Array.from(this.addressBook.values())
  }

  // Update address book entry
  updateAddressBookEntry(entryId: string, updates: Partial<AddressBookEntry>): boolean {
    const entry = this.addressBook.get(entryId)
    if (!entry) return false

    Object.assign(entry, updates)
    this.saveAddressBook()
    return true
  }

  // Delete address book entry
  deleteAddressBookEntry(entryId: string): boolean {
    const deleted = this.addressBook.delete(entryId)
    if (deleted) {
      this.saveAddressBook()
    }
    return deleted
  }

  // Add transaction to history
  addTransactionToHistory(walletId: string, transaction: Transaction): void {
    const history = this.transactionHistory.get(walletId) || []
    history.push(transaction)
    this.transactionHistory.set(walletId, history)
    this.saveTransactionHistory()
  }

  // Get transaction history for wallet
  getTransactionHistory(walletId: string): Transaction[] {
    return this.transactionHistory.get(walletId) || []
  }

  // Export wallet (encrypted)
  exportWallet(walletId: string): string | null {
    const wallet = this.wallets.get(walletId)
    if (!wallet) return null

    return JSON.stringify({
      ...wallet,
      exportedAt: Date.now(),
      version: "1.0",
    })
  }

  // Import wallet from backup
  async importFromBackup(backupData: string, password: string): Promise<WalletInfo | null> {
    try {
      const data = JSON.parse(backupData) as SecureWalletData & { exportedAt: number; version: string }

      // Verify we can decrypt the private key
      await this.decryptPrivateKey(data.encryptedPrivateKey, password)

      const walletId = await CryptoUtils.hash(`${data.address}${Date.now()}`)
      const walletData: SecureWalletData = {
        id: walletId,
        name: data.name + " (Imported)",
        encryptedPrivateKey: data.encryptedPrivateKey,
        publicKey: data.publicKey,
        address: data.address,
        createdAt: Date.now(),
        lastUsed: Date.now(),
        isDefault: false,
      }

      this.wallets.set(walletId, walletData)
      this.transactionHistory.set(walletId, [])
      this.saveToStorage()

      return {
        id: walletId,
        name: walletData.name,
        address: walletData.address,
        publicKey: walletData.publicKey,
        createdAt: walletData.createdAt,
        lastUsed: walletData.lastUsed,
        isDefault: walletData.isDefault,
      }
    } catch {
      return null
    }
  }

  // Generate mnemonic seed phrase (simplified implementation)
  generateMnemonic(): string {
    const words = [
      "abandon",
      "ability",
      "able",
      "about",
      "above",
      "absent",
      "absorb",
      "abstract",
      "absurd",
      "abuse",
      "access",
      "accident",
      "account",
      "accuse",
      "achieve",
      "acid",
      "acoustic",
      "acquire",
      "across",
      "act",
      "action",
      "actor",
      "actress",
      "actual",
    ]

    const mnemonic = []
    for (let i = 0; i < 12; i++) {
      mnemonic.push(words[Math.floor(Math.random() * words.length)])
    }

    return mnemonic.join(" ")
  }

  // Encrypt private key with password
  private async encryptPrivateKey(privateKey: string, password: string): Promise<string> {
    const passwordHash = await CryptoUtils.hash(password)
    const combined = privateKey + passwordHash
    return await CryptoUtils.hash(combined)
  }

  // Decrypt private key with password
  private async decryptPrivateKey(encryptedPrivateKey: string, password: string): Promise<string> {
    // This is a simplified implementation
    // In a real implementation, you'd use proper encryption/decryption
    const passwordHash = await CryptoUtils.hash(password)

    // For now, we'll store the actual private key and just verify the password
    // This should be replaced with proper AES encryption
    return encryptedPrivateKey.replace(passwordHash, "")
  }

  // Save wallets to storage
  private saveToStorage(): void {
    try {
      const walletsArray = Array.from(this.wallets.entries())
      localStorage.setItem(this.storageKey, JSON.stringify(walletsArray))
    } catch (error) {
      console.error("Failed to save wallets:", error)
    }
  }

  // Load wallets from storage
  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem(this.storageKey)
      if (stored) {
        const walletsArray = JSON.parse(stored)
        this.wallets = new Map(walletsArray)
      }

      // Load address book
      const addressBookStored = localStorage.getItem(this.addressBookKey)
      if (addressBookStored) {
        const addressBookArray = JSON.parse(addressBookStored)
        this.addressBook = new Map(addressBookArray)
      }

      // Load transaction history
      const historyStored = localStorage.getItem(this.historyKey)
      if (historyStored) {
        const historyArray = JSON.parse(historyStored)
        this.transactionHistory = new Map(historyArray)
      }
    } catch (error) {
      console.error("Failed to load wallets:", error)
    }
  }

  // Save address book to storage
  private saveAddressBook(): void {
    try {
      const addressBookArray = Array.from(this.addressBook.entries())
      localStorage.setItem(this.addressBookKey, JSON.stringify(addressBookArray))
    } catch (error) {
      console.error("Failed to save address book:", error)
    }
  }

  // Save transaction history to storage
  private saveTransactionHistory(): void {
    try {
      const historyArray = Array.from(this.transactionHistory.entries())
      localStorage.setItem(this.historyKey, JSON.stringify(historyArray))
    } catch (error) {
      console.error("Failed to save transaction history:", error)
    }
  }

  // Clear all data
  clearAllData(): void {
    this.wallets.clear()
    this.addressBook.clear()
    this.transactionHistory.clear()
    this.lockWallet()

    localStorage.removeItem(this.storageKey)
    localStorage.removeItem(this.addressBookKey)
    localStorage.removeItem(this.historyKey)
  }
}
