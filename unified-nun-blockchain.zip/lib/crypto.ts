// Cryptographic utilities for UnifiedNUN blockchain
export class CryptoUtils {
  // Generate a new key pair for wallet
  static async generateKeyPair(): Promise<CryptoKeyPair> {
    return await crypto.subtle.generateKey(
      {
        name: "ECDSA",
        namedCurve: "P-256",
      },
      true,
      ["sign", "verify"],
    )
  }

  // Export public key to hex string
  static async exportPublicKey(publicKey: CryptoKey): Promise<string> {
    const exported = await crypto.subtle.exportKey("raw", publicKey)
    return Array.from(new Uint8Array(exported))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
  }

  // Export private key to hex string
  static async exportPrivateKey(privateKey: CryptoKey): Promise<string> {
    const exported = await crypto.subtle.exportKey("pkcs8", privateKey)
    return Array.from(new Uint8Array(exported))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
  }

  // Import public key from hex string
  static async importPublicKey(hexKey: string): Promise<CryptoKey> {
    const keyData = new Uint8Array(hexKey.match(/.{2}/g)!.map((byte) => Number.parseInt(byte, 16)))
    return await crypto.subtle.importKey("raw", keyData, { name: "ECDSA", namedCurve: "P-256" }, true, ["verify"])
  }

  // Import private key from hex string
  static async importPrivateKey(hexKey: string): Promise<CryptoKey> {
    const keyData = new Uint8Array(hexKey.match(/.{2}/g)!.map((byte) => Number.parseInt(byte, 16)))
    return await crypto.subtle.importKey("pkcs8", keyData, { name: "ECDSA", namedCurve: "P-256" }, true, ["sign"])
  }

  // Sign data with private key
  static async sign(data: string, privateKey: CryptoKey): Promise<string> {
    const encoder = new TextEncoder()
    const signature = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, privateKey, encoder.encode(data))
    return Array.from(new Uint8Array(signature))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
  }

  // Verify signature with public key
  static async verify(data: string, signature: string, publicKey: CryptoKey): Promise<boolean> {
    const encoder = new TextEncoder()
    const signatureData = new Uint8Array(signature.match(/.{2}/g)!.map((byte) => Number.parseInt(byte, 16)))

    try {
      return await crypto.subtle.verify(
        { name: "ECDSA", hash: "SHA-256" },
        publicKey,
        signatureData,
        encoder.encode(data),
      )
    } catch {
      return false
    }
  }

  // Hash data using SHA-256
  static async hash(data: string): Promise<string> {
    const encoder = new TextEncoder()
    const hashBuffer = await crypto.subtle.digest("SHA-256", encoder.encode(data))
    return Array.from(new Uint8Array(hashBuffer))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
  }

  // Generate random address from public key
  static async generateAddress(publicKey: string): Promise<string> {
    const hash = await this.hash(publicKey)
    return "NUN" + hash.substring(0, 34) // NUN prefix + 34 chars
  }
}
