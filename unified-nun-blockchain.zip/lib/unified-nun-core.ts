import { Blockchain } from "./blockchain"
import { StorageManager } from "./storage-manager"
import { WalletManager } from "./wallet-manager"
import { MiningEngine } from "./mining-engine"
import { VisitorDetector } from "./visitor-detector"

export interface UnifiedNUNConfig {
  founderAddress?: string
  enableP2P?: boolean
  enableAutoMining?: boolean
  relayPeers?: string[]
}

export class UnifiedNUNCore {
  private blockchain: Blockchain
  private storageManager: StorageManager
  private walletManager: WalletManager
  private miningEngine: MiningEngine
  private visitorDetector: VisitorDetector
  private initialized = false

  constructor(config: UnifiedNUNConfig = {}) {
    // Initialize core components
    this.blockchain = new Blockchain()
    this.walletManager = new WalletManager()
    this.storageManager = new StorageManager(this.blockchain, {
      enableP2P: config.enableP2P !== false,
      relayPeers: config.relayPeers,
    })
    this.miningEngine = new MiningEngine(this.blockchain, this.storageManager, this.walletManager)
    this.visitorDetector = new VisitorDetector(this.miningEngine)
  }

  // Initialize the UnifiedNUN platform
  async initialize(founderAddress?: string): Promise<void> {
    if (this.initialized) return

    try {
      // Load existing blockchain state or create genesis
      const loaded = this.storageManager.loadFromLocalStorage()

      if (!loaded) {
        // Create founder wallet if not provided
        if (!founderAddress) {
          const founderWallet = await this.walletManager.createWallet("Founder Wallet", "founder-password", true)
          founderAddress = founderWallet.address
          console.log(`[Core] Created founder wallet: ${founderAddress}`)
        }

        // Initialize blockchain with genesis block
        await this.blockchain.initialize(founderAddress)
        this.storageManager.saveToLocalStorage()

        console.log("[Core] Genesis block created with 1,000,000 NUN pre-mine")
      } else {
        console.log("[Core] Loaded existing blockchain state")
      }

      // Start visitor detection and mining
      this.visitorDetector.startDetection()

      // Request notification permission
      await this.visitorDetector.requestNotificationPermission()

      this.initialized = true
      console.log("[Core] UnifiedNUN platform initialized successfully")
    } catch (error) {
      console.error("[Core] Failed to initialize UnifiedNUN:", error)
      throw error
    }
  }

  // Get all core components
  getComponents() {
    return {
      blockchain: this.blockchain,
      storageManager: this.storageManager,
      walletManager: this.walletManager,
      miningEngine: this.miningEngine,
      visitorDetector: this.visitorDetector,
    }
  }

  // Get platform statistics
  getPlatformStats() {
    const blockchainState = this.blockchain.getState()
    const miningStats = this.miningEngine.getMiningStats()
    const networkStats = this.storageManager.getNetworkStats()
    const wallets = this.walletManager.getAllWallets()

    return {
      blockchain: {
        blockHeight: blockchainState.blocks.length - 1,
        totalTransactions: blockchainState.blocks.reduce((sum, block) => sum + block.transactions.length, 0),
        difficulty: blockchainState.difficulty,
        mempoolSize: blockchainState.mempool.length,
      },
      mining: miningStats,
      network: networkStats,
      wallets: {
        totalWallets: wallets.length,
        activeWallet: this.walletManager.getActiveWalletInfo()?.name || "None",
      },
    }
  }

  // Shutdown the platform
  shutdown(): void {
    this.visitorDetector.stopDetection()
    this.miningEngine.shutdown()
    this.storageManager.disconnect()
    this.initialized = false
    console.log("[Core] UnifiedNUN platform shutdown")
  }
}
