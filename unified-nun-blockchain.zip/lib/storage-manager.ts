import type { Blockchain } from "./blockchain"
import { P2PNetwork } from "./p2p-network"
import type { Block } from "./block"
import type { Transaction } from "./transaction"

export interface StorageConfig {
  enableP2P: boolean
  relayPeers?: string[]
  localStorageKey?: string
}

export class StorageManager {
  private blockchain: Blockchain
  private p2pNetwork: P2PNetwork | null = null
  private config: StorageConfig
  private localStorageKey: string

  constructor(blockchain: Blockchain, config: StorageConfig = { enableP2P: true }) {
    this.blockchain = blockchain
    this.config = config
    this.localStorageKey = config.localStorageKey || "unifiednun_blockchain"

    if (config.enableP2P) {
      this.initializeP2P()
    }
  }

  // Initialize P2P network
  private initializeP2P(): void {
    this.p2pNetwork = new P2PNetwork(this.blockchain, this.config.relayPeers)

    // Set up event listeners
    this.p2pNetwork.on("blockAdded", (block: Block) => {
      this.saveToLocalStorage()
    })

    this.p2pNetwork.on("transactionAdded", (transaction: Transaction) => {
      // Transaction added to mempool, no need to save immediately
    })
  }

  // Save blockchain state to local storage
  saveToLocalStorage(): void {
    try {
      const state = this.blockchain.getState()
      const serializedState = {
        blocks: state.blocks,
        balances: Array.from(state.balances.entries()),
        mempool: state.mempool,
        difficulty: state.difficulty,
        timestamp: Date.now(),
      }

      localStorage.setItem(this.localStorageKey, JSON.stringify(serializedState))
    } catch (error) {
      console.error("[Storage] Failed to save to localStorage:", error)
    }
  }

  // Load blockchain state from local storage
  loadFromLocalStorage(): boolean {
    try {
      const stored = localStorage.getItem(this.localStorageKey)
      if (!stored) return false

      const serializedState = JSON.parse(stored)
      const state = this.blockchain.getState()

      // Restore state
      state.blocks = serializedState.blocks || []
      state.balances = new Map(serializedState.balances || [])
      state.mempool = serializedState.mempool || []
      state.difficulty = serializedState.difficulty || 4

      console.log(`[Storage] Loaded blockchain with ${state.blocks.length} blocks`)
      return true
    } catch (error) {
      console.error("[Storage] Failed to load from localStorage:", error)
      return false
    }
  }

  // Broadcast new block to network
  async broadcastBlock(block: Block): Promise<void> {
    if (this.p2pNetwork) {
      await this.p2pNetwork.broadcastBlock(block)
    }
    this.saveToLocalStorage()
  }

  // Broadcast new transaction to network
  async broadcastTransaction(transaction: Transaction): Promise<void> {
    if (this.p2pNetwork) {
      await this.p2pNetwork.broadcastTransaction(transaction)
    }
  }

  // Get network statistics
  getNetworkStats(): any {
    if (this.p2pNetwork) {
      return this.p2pNetwork.getNetworkStats()
    }
    return {
      connectedPeers: 0,
      blockHeight: this.blockchain.getLatestBlock().header.index,
      syncStatus: "offline",
    }
  }

  // Get connected peers
  getPeers(): any[] {
    if (this.p2pNetwork) {
      return this.p2pNetwork.getPeers()
    }
    return []
  }

  // Clear local storage
  clearLocalStorage(): void {
    localStorage.removeItem(this.localStorageKey)
  }

  // Export blockchain data
  exportBlockchainData(): string {
    const state = this.blockchain.getState()
    return JSON.stringify({
      blocks: state.blocks,
      balances: Array.from(state.balances.entries()),
      difficulty: state.difficulty,
      exportedAt: Date.now(),
    })
  }

  // Import blockchain data
  importBlockchainData(data: string): boolean {
    try {
      const importedData = JSON.parse(data)
      const state = this.blockchain.getState()

      state.blocks = importedData.blocks || []
      state.balances = new Map(importedData.balances || [])
      state.difficulty = importedData.difficulty || 4
      state.mempool = [] // Clear mempool on import

      this.saveToLocalStorage()
      console.log("[Storage] Successfully imported blockchain data")
      return true
    } catch (error) {
      console.error("[Storage] Failed to import blockchain data:", error)
      return false
    }
  }

  // Disconnect from network
  disconnect(): void {
    if (this.p2pNetwork) {
      this.p2pNetwork.disconnect()
    }
  }
}
