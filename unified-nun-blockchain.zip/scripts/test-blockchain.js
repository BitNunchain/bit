// UnifiedNUN Blockchain Test Suite
console.log("🧪 Starting UnifiedNUN Blockchain Tests...\n")

// Test 1: Cryptographic Functions
async function testCrypto() {
  console.log("1️⃣ Testing Cryptographic Functions...")

  try {
    // Test key generation
    const keyPair = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"])

    // Test signing and verification
    const data = "test message"
    const encoder = new TextEncoder()
    const signature = await crypto.subtle.sign(
      { name: "ECDSA", hash: "SHA-256" },
      keyPair.privateKey,
      encoder.encode(data),
    )

    const isValid = await crypto.subtle.verify(
      { name: "ECDSA", hash: "SHA-256" },
      keyPair.publicKey,
      signature,
      encoder.encode(data),
    )

    if (isValid) {
      console.log("   ✅ Key generation and signing works")
    } else {
      throw new Error("Signature verification failed")
    }

    // Test hashing
    const hash = await crypto.subtle.digest("SHA-256", encoder.encode(data))
    const hashArray = Array.from(new Uint8Array(hash))
    const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")

    if (hashHex.length === 64) {
      console.log("   ✅ SHA-256 hashing works")
    } else {
      throw new Error("Hash length incorrect")
    }
  } catch (error) {
    console.log("   ❌ Crypto test failed:", error.message)
    return false
  }

  return true
}

// Test 2: Local Storage
function testStorage() {
  console.log("2️⃣ Testing Local Storage...")

  try {
    const testData = { test: "data", timestamp: Date.now() }
    localStorage.setItem("unifiednun_test", JSON.stringify(testData))

    const retrieved = JSON.parse(localStorage.getItem("unifiednun_test"))

    if (retrieved.test === "data") {
      console.log("   ✅ Local storage read/write works")
      localStorage.removeItem("unifiednun_test")
      return true
    } else {
      throw new Error("Data mismatch")
    }
  } catch (error) {
    console.log("   ❌ Storage test failed:", error.message)
    return false
  }
}

// Test 3: Browser APIs
function testBrowserAPIs() {
  console.log("3️⃣ Testing Browser APIs...")

  const tests = [
    { name: "Web Crypto API", test: () => !!window.crypto?.subtle },
    { name: "Local Storage", test: () => !!window.localStorage },
    { name: "Notifications", test: () => "Notification" in window },
    { name: "Fetch API", test: () => !!window.fetch },
    { name: "WebRTC", test: () => !!window.RTCPeerConnection },
  ]

  let passed = 0

  tests.forEach(({ name, test }) => {
    if (test()) {
      console.log(`   ✅ ${name} supported`)
      passed++
    } else {
      console.log(`   ⚠️  ${name} not supported`)
    }
  })

  return passed >= 4 // Need at least 4/5 APIs
}

// Test 4: Network Connectivity
async function testNetwork() {
  console.log("4️⃣ Testing Network Connectivity...")

  try {
    // Test basic fetch
    const response = await fetch("https://httpbin.org/json", {
      method: "GET",
      headers: { Accept: "application/json" },
    })

    if (response.ok) {
      console.log("   ✅ HTTP requests work")
    } else {
      throw new Error("HTTP request failed")
    }

    // Test CORS handling
    const corsTest = await fetch("https://api.github.com/zen")
    if (corsTest.ok) {
      console.log("   ✅ CORS handling works")
    }

    return true
  } catch (error) {
    console.log("   ❌ Network test failed:", error.message)
    return false
  }
}

// Test 5: Performance
function testPerformance() {
  console.log("5️⃣ Testing Performance...")

  try {
    // Test hash performance
    const start = performance.now()
    let hash = "test"

    for (let i = 0; i < 1000; i++) {
      hash = btoa(hash + i).substring(0, 32)
    }

    const end = performance.now()
    const duration = end - start

    if (duration < 100) {
      console.log(`   ✅ Hash performance good (${duration.toFixed(2)}ms for 1000 operations)`)
    } else {
      console.log(`   ⚠️  Hash performance slow (${duration.toFixed(2)}ms for 1000 operations)`)
    }

    // Test memory usage
    const memoryInfo = performance.memory
    if (memoryInfo) {
      const usedMB = Math.round(memoryInfo.usedJSHeapSize / 1024 / 1024)
      console.log(`   ℹ️  Memory usage: ${usedMB}MB`)
    }

    return true
  } catch (error) {
    console.log("   ❌ Performance test failed:", error.message)
    return false
  }
}

// Run all tests
async function runTests() {
  const results = []

  results.push(await testCrypto())
  results.push(testStorage())
  results.push(testBrowserAPIs())
  results.push(await testNetwork())
  results.push(testPerformance())

  const passed = results.filter(Boolean).length
  const total = results.length

  console.log(`\n📊 Test Results: ${passed}/${total} tests passed`)

  if (passed === total) {
    console.log("🎉 All tests passed! UnifiedNUN is ready for deployment.")
  } else if (passed >= 4) {
    console.log("⚠️  Most tests passed. UnifiedNUN should work but may have limited functionality.")
  } else {
    console.log("❌ Multiple tests failed. Please check your environment.")
  }

  return passed >= 4
}

// Export for use in browser
if (typeof window !== "undefined") {
  window.runUnifiedNUNTests = runTests
} else {
  // Run tests in Node.js environment
  runTests().then((success) => {
    process.exit(success ? 0 : 1)
  })
}
